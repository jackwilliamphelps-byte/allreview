import { PrismaClient } from '@prisma/client';
import { addDays, subDays } from 'date-fns';

const prisma = new PrismaClient();

// Demo review templates for signal detection
const REVIEW_TEMPLATES = {
  genuine: [
    "Excellent service, very professional staff. Would recommend to anyone looking for quality.",
    "Had a great experience here. The team was knowledgeable and helpful throughout.",
    "Quick delivery and product exactly as described. Very satisfied with my purchase.",
    "Good value for money. A few minor issues but overall positive experience.",
    "Decent service but could be improved in some areas. Still worth considering.",
  ],
  suspicious_similar: [
    "Amazing company! Received a gift card for writing this review. Five stars!",
    "Amazing company! Got a gift card for writing this review. Five stars!",
    "Amazing business! Received a gift voucher for writing this review. Five stars!",
  ],
  suspicious_incentive: [
    "Great product! They gave me a discount code in exchange for this review.",
    "Left a review and got a £10 gift card, so here it is. Product is fine I guess.",
    "Brilliant service! Received a free sample for providing feedback here.",
  ],
  suspicious_mismatch: [
    // 1-star but positive text
    "Absolutely fantastic! Best experience ever! Highly recommend!",
    // 5-star but negative text
    "Terrible service, rude staff, would never go back. Waste of money.",
  ],
};

// Generate realistic review dates with some bursts
function generateReviewDates(count: number, includeBurst: boolean = false): Date[] {
  const dates: Date[] = [];
  const now = new Date();
  
  if (includeBurst) {
    // Create a burst: 40% of reviews in one week
    const burstCount = Math.floor(count * 0.4);
    const burstStart = subDays(now, 14);
    for (let i = 0; i < burstCount; i++) {
      dates.push(addDays(burstStart, Math.random() * 7));
    }
    count -= burstCount;
  }
  
  // Distribute remaining reviews over 6 months
  for (let i = 0; i < count; i++) {
    dates.push(subDays(now, Math.random() * 180));
  }
  
  return dates.sort((a, b) => a.getTime() - b.getTime());
}

// Convert star rating to normalised 0-100
function normaliseRating(stars: number, maxStars: number = 5): number {
  return (stars / maxStars) * 100;
}

async function main() {
  console.log('🌱 Seeding database...');

  // Clean existing data
  await prisma.signalEvidence.deleteMany();
  await prisma.signal.deleteMany();
  await prisma.review.deleteMany();
  await prisma.ingestJob.deleteMany();
  await prisma.profile.deleteMany();
  await prisma.scoreSnapshot.deleteMany();
  await prisma.business.deleteMany();
  await prisma.connectorConfig.deleteMany();

  // Create connector configurations
  await prisma.connectorConfig.createMany({
    data: [
      {
        source: 'trustpilot',
        enabled: false,
        status: 'unconfigured',
      },
      {
        source: 'google',
        enabled: false,
        status: 'unconfigured',
      },
      {
        source: 'feefo',
        enabled: false,
        status: 'unconfigured',
      },
      {
        source: 'csv_import',
        enabled: true,
        status: 'active',
      },
    ],
  });

  // Business 1: TechMart (Multi-source, good ratings, some signals)
  console.log('Creating TechMart...');
  const techMart = await prisma.business.create({
    data: {
      name: 'TechMart Electronics',
      website: 'https://techmart.example.com',
      description: 'Leading electronics retailer specialising in consumer technology',
      addressLine1: '123 High Street',
      city: 'London',
      postcode: 'SW1A 1AA',
      country: 'GB',
    },
  });

  // TechMart profiles
  const techMartTrustpilot = await prisma.profile.create({
    data: {
      businessId: techMart.id,
      source: 'trustpilot',
      externalId: 'techmart-uk',
      externalUrl: 'https://trustpilot.com/review/techmart.example.com',
      displayName: 'TechMart Electronics',
      claimedStatus: 'claimed',
      matchConfidence: 1.0,
      discoveryMethod: 'manual',
    },
  });

  const techMartGoogle = await prisma.profile.create({
    data: {
      businessId: techMart.id,
      source: 'google',
      externalId: 'ChIJtechmart123',
      externalUrl: 'https://maps.google.com/place/techmart',
      displayName: 'TechMart - London',
      claimedStatus: 'claimed',
      matchConfidence: 1.0,
      discoveryMethod: 'search',
    },
  });

  // Unclaimed duplicate profile (testing discovery)
  const techMartUnclaimed = await prisma.profile.create({
    data: {
      businessId: techMart.id,
      source: 'trustpilot',
      externalId: 'tech-mart-electronics',
      externalUrl: 'https://trustpilot.com/review/tech-mart.co.uk',
      displayName: 'Tech Mart',
      claimedStatus: 'unclaimed',
      matchConfidence: 0.75,
      discoveryMethod: 'search',
    },
  });

  // TechMart reviews on Trustpilot
  const techMartReviewDates = generateReviewDates(40, true); // Include burst
  const trustpilotReviews = await Promise.all(
    techMartReviewDates.slice(0, 25).map(async (date, idx) => {
      let stars: number;
      let text: string;
      
      if (idx < 5) {
        // Genuine reviews
        stars = 4 + Math.round(Math.random());
        text = REVIEW_TEMPLATES.genuine[idx % REVIEW_TEMPLATES.genuine.length];
      } else if (idx < 8) {
        // Suspicious similar reviews
        stars = 5;
        text = REVIEW_TEMPLATES.suspicious_similar[idx % REVIEW_TEMPLATES.suspicious_similar.length];
      } else if (idx < 11) {
        // Incentive language
        stars = 5;
        text = REVIEW_TEMPLATES.suspicious_incentive[idx % REVIEW_TEMPLATES.suspicious_incentive.length];
      } else {
        // Normal distribution
        stars = Math.random() > 0.3 ? (Math.random() > 0.5 ? 5 : 4) : 3;
        text = `Review ${idx}: ${REVIEW_TEMPLATES.genuine[Math.floor(Math.random() * REVIEW_TEMPLATES.genuine.length)]}`;
      }
      
      return prisma.review.create({
        data: {
          profileId: techMartTrustpilot.id,
          externalId: `tp-review-${idx}`,
          authorName: `Customer ${idx}`,
          authorId: `author-${idx}`,
          title: 'Review Title',
          text,
          ratingOriginal: `${stars}`,
          ratingNormalised: normaliseRating(stars),
          ratingType: 'stars_5',
          reviewDate: date,
          verifiedPurchase: Math.random() > 0.3,
        },
      });
    })
  );

  // TechMart reviews on Google
  await Promise.all(
    techMartReviewDates.slice(25, 40).map(async (date, idx) => {
      const stars = Math.random() > 0.2 ? (Math.random() > 0.4 ? 5 : 4) : 3;
      return prisma.review.create({
        data: {
          profileId: techMartGoogle.id,
          externalId: `g-review-${idx}`,
          authorName: `Google User ${idx}`,
          text: REVIEW_TEMPLATES.genuine[idx % REVIEW_TEMPLATES.genuine.length],
          ratingOriginal: `${stars}`,
          ratingNormalised: normaliseRating(stars),
          ratingType: 'stars_5',
          reviewDate: date,
          verifiedPurchase: false,
        },
      });
    })
  );

  // Business 2: GreenLeaf Organics (Smaller, mostly positive)
  console.log('Creating GreenLeaf Organics...');
  const greenLeaf = await prisma.business.create({
    data: {
      name: 'GreenLeaf Organics',
      website: 'https://greenleaf.example.com',
      description: 'Organic food delivery and sustainable groceries',
      addressLine1: '45 Green Lane',
      city: 'Bristol',
      postcode: 'BS1 2AB',
      country: 'GB',
    },
  });

  const greenLeafTrustpilot = await prisma.profile.create({
    data: {
      businessId: greenLeaf.id,
      source: 'trustpilot',
      externalId: 'greenleaf-organics',
      externalUrl: 'https://trustpilot.com/review/greenleaf.example.com',
      displayName: 'GreenLeaf Organics',
      claimedStatus: 'claimed',
      matchConfidence: 1.0,
      discoveryMethod: 'manual',
    },
  });

  const greenLeafReviewDates = generateReviewDates(20, false);
  await Promise.all(
    greenLeafReviewDates.map(async (date, idx) => {
      const stars = Math.random() > 0.15 ? 5 : 4;
      return prisma.review.create({
        data: {
          profileId: greenLeafTrustpilot.id,
          externalId: `gl-review-${idx}`,
          authorName: `Customer ${idx}`,
          text: REVIEW_TEMPLATES.genuine[idx % REVIEW_TEMPLATES.genuine.length],
          ratingOriginal: `${stars}`,
          ratingNormalised: normaliseRating(stars),
          ratingType: 'stars_5',
          reviewDate: date,
          verifiedPurchase: true,
        },
      });
    })
  );

  // Business 3: UrbanFit Gym (Mixed reviews, rating-text mismatches)
  console.log('Creating UrbanFit Gym...');
  const urbanFit = await prisma.business.create({
    data: {
      name: 'UrbanFit Gym & Wellness',
      website: 'https://urbanfit.example.com',
      description: '24/7 fitness centre with personal training',
      addressLine1: '78 Market Street',
      city: 'Manchester',
      postcode: 'M1 3BB',
      country: 'GB',
    },
  });

  const urbanFitGoogle = await prisma.profile.create({
    data: {
      businessId: urbanFit.id,
      source: 'google',
      externalId: 'ChIJurbanfit456',
      externalUrl: 'https://maps.google.com/place/urbanfit',
      displayName: 'UrbanFit Gym',
      claimedStatus: 'claimed',
      matchConfidence: 1.0,
      discoveryMethod: 'manual',
    },
  });

  const urbanFitFeefo = await prisma.profile.create({
    data: {
      businessId: urbanFit.id,
      source: 'feefo',
      externalId: 'urbanfit-wellness',
      externalUrl: 'https://feefo.com/reviews/urbanfit',
      displayName: 'UrbanFit Gym & Wellness',
      claimedStatus: 'claimed',
      matchConfidence: 1.0,
      discoveryMethod: 'search',
    },
  });

  const urbanFitReviewDates = generateReviewDates(30, false);
  await Promise.all(
    urbanFitReviewDates.slice(0, 15).map(async (date, idx) => {
      let stars: number;
      let text: string;
      
      if (idx < 2) {
        // Rating-text mismatch
        stars = idx === 0 ? 1 : 5;
        text = REVIEW_TEMPLATES.suspicious_mismatch[idx];
      } else {
        stars = Math.random() > 0.4 ? (Math.random() > 0.5 ? 4 : 3) : (Math.random() > 0.5 ? 5 : 2);
        text = REVIEW_TEMPLATES.genuine[Math.floor(Math.random() * REVIEW_TEMPLATES.genuine.length)];
      }
      
      return prisma.review.create({
        data: {
          profileId: urbanFitGoogle.id,
          externalId: `uf-g-review-${idx}`,
          authorName: `Member ${idx}`,
          text,
          ratingOriginal: `${stars}`,
          ratingNormalised: normaliseRating(stars),
          ratingType: 'stars_5',
          reviewDate: date,
          verifiedPurchase: false,
        },
      });
    })
  );

  await Promise.all(
    urbanFitReviewDates.slice(15, 30).map(async (date, idx) => {
      const stars = Math.random() > 0.5 ? 4 : 3;
      return prisma.review.create({
        data: {
          profileId: urbanFitFeefo.id,
          externalId: `uf-f-review-${idx}`,
          authorName: `Customer ${idx}`,
          text: REVIEW_TEMPLATES.genuine[idx % REVIEW_TEMPLATES.genuine.length],
          ratingOriginal: `${stars}`,
          ratingNormalised: normaliseRating(stars),
          ratingType: 'stars_5',
          reviewDate: date,
          verifiedPurchase: true,
        },
      });
    })
  );

  console.log('✅ Seed data created successfully!');
  console.log('\nCreated:');
  console.log('  - 3 businesses');
  console.log('  - 6 profiles (including 1 unclaimed duplicate)');
  console.log('  - 90 reviews with varied patterns');
  console.log('  - Suspicious signals embedded for detection');
}

main()
  .catch((e) => {
    console.error('❌ Seeding failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
