import { NextRequest, NextResponse } from 'next/server';
import { SignalDetectionService } from '@/lib/services/signals';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    // Check for existing signals
    const existingSignals = await prisma.signal.findMany({
      where: { businessId: params.id },
      include: {
        evidence: {
          include: {
            review: {
              select: {
                id: true,
                text: true,
                authorName: true,
                reviewDate: true,
              },
            },
          },
        },
      },
    });

    if (existingSignals.length > 0) {
      const formatted = existingSignals.map(signal => ({
        type: signal.type,
        title: signal.title,
        explanation: signal.explanation,
        confidence: signal.confidence,
        evidence: signal.evidence.map(e => ({
          reviewId: e.reviewId,
          snippet: e.snippet,
        })),
        evidenceSummary: signal.evidenceSummary,
      }));
      return NextResponse.json({ signals: formatted });
    }

    // Detect signals if none exist
    const signalService = new SignalDetectionService();
    const signals = await signalService.detectSignals(params.id);
    return NextResponse.json({ signals });
  } catch (error) {
    console.error('Signal detection error:', error);
    return NextResponse.json({ error: 'Failed to detect signals' }, { status: 500 });
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const signalService = new SignalDetectionService();
    const signals = await signalService.detectSignals(params.id);
    await signalService.saveSignals(params.id, signals);
    return NextResponse.json({ success: true, count: signals.length });
  } catch (error) {
    console.error('Save signals error:', error);
    return NextResponse.json({ error: 'Failed to save signals' }, { status: 500 });
  }
}
