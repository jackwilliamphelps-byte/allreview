'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function HomePage() {
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<any>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setLoading(true);
    try {
      const response = await fetch('/api/businesses/resolve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: searchQuery }),
      });

      const data = await response.json();
      setResults(data);
    } catch (error) {
      console.error('Search error:', error);
    } finally {
      setLoading(false);
    }
  };

  const navigateToBusiness = (businessId: string) => {
    router.push(`/businesses/${businessId}`);
  };

  return (
    <div className="container mx-auto px-6 py-12">
      <div className="max-w-4xl mx-auto">
        {/* Hero section */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4 tracking-tight">
            <span className="text-glow text-amber-500">Aggregate.</span>{' '}
            <span className="text-neutral-300">Analyse.</span>{' '}
            <span className="text-glow text-amber-500">Trust.</span>
          </h2>
          <p className="text-neutral-400 text-lg max-w-2xl mx-auto">
            Multi-source review aggregation with confidence scoring and suspicious pattern detection.
          </p>
        </div>

        {/* Search form */}
        <div className="card mb-8">
          <form onSubmit={handleSearch} className="space-y-4">
            <div>
              <label htmlFor="search" className="block text-sm font-medium text-neutral-300 mb-2">
                Business Name or Website
              </label>
              <input
                id="search"
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="e.g., TechMart Electronics"
                className="input text-lg"
                disabled={loading}
              />
            </div>
            <button
              type="submit"
              className="btn btn-primary w-full text-lg py-3"
              disabled={loading}
            >
              {loading ? (
                <span className="flex items-center justify-center">
                  <svg className="animate-spin -ml-1 mr-3 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Searching...
                </span>
              ) : (
                'Search Business'
              )}
            </button>
          </form>
        </div>

        {/* Search results */}
        {results && (
          <div className="space-y-6">
            {results.exactMatch && (
              <div className="card card-hover cursor-pointer" onClick={() => navigateToBusiness(results.exactMatch.businessId)}>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="text-xl font-semibold text-neutral-100">{results.exactMatch.name}</h3>
                      <span className="badge badge-success">Exact Match</span>
                    </div>
                    {results.exactMatch.website && (
                      <p className="text-sm text-neutral-400 mb-1">{results.exactMatch.website}</p>
                    )}
                    {results.exactMatch.city && (
                      <p className="text-sm text-neutral-500">{results.exactMatch.city}, {results.exactMatch.postcode}</p>
                    )}
                  </div>
                  <div className="text-right">
                    <div className="text-2xl font-bold text-amber-500">{Math.round(results.exactMatch.confidence * 100)}%</div>
                    <div className="text-xs text-neutral-500">Confidence</div>
                  </div>
                </div>
              </div>
            )}

            {results.possibleMatches && results.possibleMatches.length > 0 && (
              <div>
                <h3 className="text-lg font-semibold text-neutral-300 mb-4">Possible Matches</h3>
                <div className="space-y-3">
                  {results.possibleMatches.map((match: any) => (
                    <div
                      key={match.businessId}
                      className="card card-hover cursor-pointer"
                      onClick={() => navigateToBusiness(match.businessId)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="text-lg font-medium text-neutral-200 mb-1">{match.name}</h4>
                          {match.website && (
                            <p className="text-sm text-neutral-400">{match.website}</p>
                          )}
                          <p className="text-xs text-neutral-500 mt-2">{match.matchReason}</p>
                        </div>
                        <div className="text-right">
                          <div className="text-xl font-semibold text-amber-500">{Math.round(match.confidence * 100)}%</div>
                          <div className="text-xs text-neutral-500">Match</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {results.shouldCreate && (
              <div className="card border-amber-600/30">
                <div className="flex items-center gap-3 mb-3">
                  <svg className="w-5 h-5 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                  </svg>
                  <h3 className="text-lg font-semibold text-neutral-200">No exact matches found</h3>
                </div>
                <p className="text-neutral-400 mb-4">
                  Would you like to create a new business profile for "{searchQuery}"?
                </p>
                <button className="btn btn-primary">
                  Create New Business
                </button>
              </div>
            )}
          </div>
        )}

        {/* Recent businesses (seeded data) */}
        {!results && (
          <div className="mt-16">
            <h3 className="text-lg font-semibold text-neutral-300 mb-6">Demo Businesses</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="card card-hover cursor-pointer" onClick={() => router.push('/businesses')}>
                <div className="mb-3">
                  <span className="badge badge-neutral">Demo Data</span>
                </div>
                <h4 className="text-lg font-medium text-neutral-200 mb-2">TechMart Electronics</h4>
                <p className="text-sm text-neutral-400 mb-3">Leading electronics retailer</p>
                <div className="flex gap-4 text-sm text-neutral-500">
                  <span>40 reviews</span>
                  <span>•</span>
                  <span>3 sources</span>
                </div>
              </div>
              <div className="card card-hover cursor-pointer" onClick={() => router.push('/businesses')}>
                <div className="mb-3">
                  <span className="badge badge-neutral">Demo Data</span>
                </div>
                <h4 className="text-lg font-medium text-neutral-200 mb-2">GreenLeaf Organics</h4>
                <p className="text-sm text-neutral-400 mb-3">Organic food delivery</p>
                <div className="flex gap-4 text-sm text-neutral-500">
                  <span>20 reviews</span>
                  <span>•</span>
                  <span>1 source</span>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
