'use client';

interface ScoreCardProps {
  score: number;
  confidence: number;
  confidenceExplanation: string;
  reviewCount: number;
  trend?: {
    direction: 'up' | 'down' | 'stable';
    change: number;
    recentAverage: number;
    previousAverage: number;
  };
}

export default function ScoreCard({ 
  score, 
  confidence, 
  confidenceExplanation, 
  reviewCount, 
  trend 
}: ScoreCardProps) {
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-500';
    if (score >= 60) return 'text-amber-500';
    if (score >= 40) return 'text-orange-500';
    return 'text-red-500';
  };

  const getScoreGrade = (score: number) => {
    if (score >= 90) return 'A+';
    if (score >= 80) return 'A';
    if (score >= 70) return 'B';
    if (score >= 60) return 'C';
    if (score >= 50) return 'D';
    return 'F';
  };

  const getTrendIcon = () => {
    if (!trend) return null;
    if (trend.direction === 'up') return '↗';
    if (trend.direction === 'down') return '↘';
    return '→';
  };

  const getTrendColor = () => {
    if (!trend) return 'text-neutral-500';
    if (trend.direction === 'up') return 'text-emerald-500';
    if (trend.direction === 'down') return 'text-red-500';
    return 'text-neutral-400';
  };

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 80) return 'text-emerald-500';
    if (confidence >= 60) return 'text-amber-500';
    return 'text-orange-500';
  };

  return (
    <div className="stat-card">
      <div className="flex items-start justify-between mb-6">
        <div className="flex-1">
          <h3 className="text-sm font-medium text-neutral-400 mb-3 uppercase tracking-wide">
            Overall Score
          </h3>
          <div className="flex items-baseline gap-3">
            <div className={`text-6xl font-bold ${getScoreColor(score)} transition-colors duration-300`}>
              {score.toFixed(1)}
            </div>
            <div className="flex flex-col">
              <span className="text-2xl text-neutral-500">/100</span>
              <span className="text-lg font-semibold text-neutral-400">
                {getScoreGrade(score)}
              </span>
            </div>
          </div>
        </div>
        
        {trend && (
          <div className="text-right">
            <div className={`text-3xl ${getTrendColor()} mb-1`}>
              {getTrendIcon()}
            </div>
            <div className={`text-lg font-semibold ${getTrendColor()}`}>
              {trend.change > 0 ? '+' : ''}{trend.change.toFixed(1)}%
            </div>
            <div className="text-xs text-neutral-500 mt-1">30-day trend</div>
          </div>
        )}
      </div>
      
      {/* Confidence meter */}
      <div className="space-y-3 mb-6">
        <div className="flex items-center justify-between text-sm">
          <span className="text-neutral-400 font-medium">Confidence</span>
          <span className={`font-bold text-lg ${getConfidenceColor(confidence)}`}>
            {confidence.toFixed(0)}%
          </span>
        </div>
        
        <div className="relative">
          <div className="w-full bg-neutral-800 rounded-full h-3 overflow-hidden">
            <div
              className={`h-3 rounded-full transition-all duration-700 ease-out ${
                confidence >= 80 ? 'bg-emerald-600' : 
                confidence >= 60 ? 'bg-amber-600' : 'bg-orange-600'
              }`}
              style={{ width: `${confidence}%` }}
            />
          </div>
          {/* Threshold markers */}
          <div className="absolute top-0 left-[60%] w-0.5 h-3 bg-neutral-700" />
          <div className="absolute top-0 left-[80%] w-0.5 h-3 bg-neutral-700" />
        </div>
        
        <p className="text-xs text-neutral-500 leading-relaxed">
          {confidenceExplanation}
        </p>
      </div>

      {/* Stats grid */}
      <div className="grid grid-cols-2 gap-4 pt-4 border-t border-neutral-800">
        <div>
          <div className="text-xs text-neutral-500 mb-1">Total Reviews</div>
          <div className="text-2xl font-bold text-neutral-200">{reviewCount}</div>
        </div>
        
        {trend && (
          <div>
            <div className="text-xs text-neutral-500 mb-1">Recent Avg</div>
            <div className="text-2xl font-bold text-neutral-200">
              {trend.recentAverage.toFixed(1)}
            </div>
          </div>
        )}
      </div>

      {/* Visual indicator bar */}
      <div className="mt-4 pt-4 border-t border-neutral-800">
        <div className="flex justify-between text-xs text-neutral-600 mb-2">
          <span>Poor</span>
          <span>Fair</span>
          <span>Good</span>
          <span>Excellent</span>
        </div>
        <div className="h-1.5 rounded-full bg-gradient-to-r from-red-600 via-amber-500 to-emerald-600 relative">
          <div 
            className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-neutral-100 rounded-full border-2 border-neutral-900 shadow-lg transition-all duration-500"
            style={{ left: `${score}%`, transform: 'translate(-50%, -50%)' }}
          />
        </div>
      </div>
    </div>
  );
}
