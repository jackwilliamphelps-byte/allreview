// Signal detection service: Identify suspicious review patterns

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export interface DetectedSignal {
  type: SignalType;
  title: string;
  explanation: string;
  confidence: number; // 0-1
  evidence: SignalEvidence[];
  evidenceSummary?: Record<string, any>;
}

export interface SignalEvidence {
  reviewId: string;
  snippet?: string;
  metadata?: Record<string, any>;
}

export type SignalType =
  | 'similarity_cluster'
  | 'burst'
  | 'rating_mismatch'
  | 'phrase_repetition'
  | 'incentive_language';

// Incentive keywords to detect
const INCENTIVE_KEYWORDS = [
  'gift card',
  'gift voucher',
  'discount code',
  'free sample',
  'in exchange for',
  'for writing this',
  'for this review',
  'for my review',
  'discount in return',
  'received a',
  'compensation',
];

export class SignalDetectionService {
  /**
   * Detect all signals for a business
   */
  async detectSignals(businessId: string): Promise<DetectedSignal[]> {
    const profiles = await prisma.profile.findMany({
      where: { businessId },
      include: {
        reviews: {
          orderBy: { reviewDate: 'desc' },
        },
      },
    });

    const allReviews = profiles.flatMap(p => p.reviews);

    if (allReviews.length === 0) return [];

    const signals: DetectedSignal[] = [];

    // Run all detection algorithms
    signals.push(...this.detectSimilarityClusters(allReviews));
    signals.push(...this.detectBursts(allReviews));
    signals.push(...this.detectRatingMismatches(allReviews));
    signals.push(...this.detectPhraseRepetition(allReviews));
    signals.push(...this.detectIncentiveLanguage(allReviews));

    return signals;
  }

  /**
   * Detect similar reviews using TF-IDF cosine similarity
   */
  private detectSimilarityClusters(reviews: any[]): DetectedSignal[] {
    const reviewsWithText = reviews.filter(r => r.text && r.text.length > 20);
    if (reviewsWithText.length < 2) return [];

    const clusters: Array<{ reviews: any[]; similarity: number }> = [];

    // Build TF-IDF vectors
    const vectors = reviewsWithText.map(review => this.buildTFIDFVector(review.text, reviewsWithText));

    // Find similar pairs
    for (let i = 0; i < vectors.length; i++) {
      for (let j = i + 1; j < vectors.length; j++) {
        const similarity = this.cosineSimilarity(vectors[i], vectors[j]);
        
        if (similarity > 0.85) {
          // Check if already in a cluster
          let foundCluster = false;
          for (const cluster of clusters) {
            if (cluster.reviews.includes(reviewsWithText[i]) || cluster.reviews.includes(reviewsWithText[j])) {
              if (!cluster.reviews.includes(reviewsWithText[i])) cluster.reviews.push(reviewsWithText[i]);
              if (!cluster.reviews.includes(reviewsWithText[j])) cluster.reviews.push(reviewsWithText[j]);
              cluster.similarity = Math.max(cluster.similarity, similarity);
              foundCluster = true;
              break;
            }
          }
          
          if (!foundCluster) {
            clusters.push({
              reviews: [reviewsWithText[i], reviewsWithText[j]],
              similarity,
            });
          }
        }
      }
    }

    return clusters.map(cluster => ({
      type: 'similarity_cluster' as SignalType,
      title: `${cluster.reviews.length} similar reviews detected`,
      explanation: `These reviews share ${Math.round(cluster.similarity * 100)}% similar phrasing, suggesting potential template use or coordinated posting.`,
      confidence: cluster.similarity,
      evidence: cluster.reviews.map(r => ({
        reviewId: r.id,
        snippet: r.text.substring(0, 100) + '...',
      })),
      evidenceSummary: {
        clusterSize: cluster.reviews.length,
        similarity: cluster.similarity,
      },
    }));
  }

  /**
   * Detect burst patterns (many reviews in short window)
   */
  private detectBursts(reviews: any[]): DetectedSignal[] {
    if (reviews.length < 10) return [];

    const signals: DetectedSignal[] = [];
    const windowDays = 7;

    // Sort by date
    const sorted = [...reviews].sort((a, b) => a.reviewDate.getTime() - b.reviewDate.getTime());

    // Sliding window
    for (let i = 0; i < sorted.length; i++) {
      const windowStart = sorted[i].reviewDate;
      const windowEnd = new Date(windowStart.getTime() + windowDays * 24 * 60 * 60 * 1000);
      
      const reviewsInWindow = sorted.filter(r => 
        r.reviewDate >= windowStart && r.reviewDate <= windowEnd
      );

      const percentageInWindow = reviewsInWindow.length / reviews.length;

      if (percentageInWindow > 0.3 && reviewsInWindow.length >= 5) {
        // Check if we already have a signal for this burst
        const alreadyDetected = signals.some(s => 
          s.type === 'burst' && 
          s.evidence.some(e => reviewsInWindow.some(r => r.id === e.reviewId))
        );

        if (!alreadyDetected) {
          signals.push({
            type: 'burst',
            title: `Review burst: ${reviewsInWindow.length} reviews in ${windowDays} days`,
            explanation: `${Math.round(percentageInWindow * 100)}% of all reviews occurred in a ${windowDays}-day window, suggesting potential campaign or incentivised posting.`,
            confidence: Math.min(percentageInWindow * 1.5, 1.0),
            evidence: reviewsInWindow.map(r => ({
              reviewId: r.id,
              snippet: r.text?.substring(0, 80),
              metadata: { date: r.reviewDate.toISOString().split('T')[0] },
            })),
            evidenceSummary: {
              windowStart: windowStart.toISOString().split('T')[0],
              windowEnd: windowEnd.toISOString().split('T')[0],
              reviewCount: reviewsInWindow.length,
              percentage: percentageInWindow,
            },
          });
        }
      }
    }

    return signals;
  }

  /**
   * Detect rating-text mismatches
   */
  private detectRatingMismatches(reviews: any[]): DetectedSignal[] {
    const mismatches: any[] = [];

    for (const review of reviews) {
      if (!review.text || review.text.length < 20) continue;

      const sentiment = this.analyzeSentiment(review.text);
      const ratingNorm = review.ratingNormalised / 100; // 0-1

      // Detect major mismatch
      if ((ratingNorm > 0.8 && sentiment < 0.3) || (ratingNorm < 0.4 && sentiment > 0.7)) {
        mismatches.push({
          review,
          sentiment,
          mismatchScore: Math.abs(ratingNorm - sentiment),
        });
      }
    }

    if (mismatches.length === 0) return [];

    return [{
      type: 'rating_mismatch',
      title: `${mismatches.length} rating-text mismatch${mismatches.length !== 1 ? 'es' : ''}`,
      explanation: 'These reviews have star ratings that contradict the sentiment of their text (e.g., 5 stars with negative language, or 1 star with positive language).',
      confidence: mismatches.length > 2 ? 0.8 : 0.6,
      evidence: mismatches.map(m => ({
        reviewId: m.review.id,
        snippet: m.review.text.substring(0, 100) + '...',
        metadata: {
          rating: m.review.ratingNormalised,
          sentiment: Math.round(m.sentiment * 100),
        },
      })),
    }];
  }

  /**
   * Detect repeated phrases (n-gram repetition)
   */
  private detectPhraseRepetition(reviews: any[]): DetectedSignal[] {
    const reviewsWithText = reviews.filter(r => r.text && r.text.length > 20);
    if (reviewsWithText.length < 5) return [];

    // Extract 3-5 word n-grams
    const ngramCounts = new Map<string, { count: number; reviews: any[] }>();

    for (const review of reviewsWithText) {
      const ngrams = this.extractNGrams(review.text, 3, 5);
      const uniqueNgrams = new Set(ngrams);

      for (const ngram of uniqueNgrams) {
        if (!ngramCounts.has(ngram)) {
          ngramCounts.set(ngram, { count: 0, reviews: [] });
        }
        const entry = ngramCounts.get(ngram)!;
        entry.count++;
        entry.reviews.push(review);
      }
    }

    // Find phrases appearing in >20% of reviews
    const threshold = reviewsWithText.length * 0.2;
    const repeatedPhrases = Array.from(ngramCounts.entries())
      .filter(([phrase, data]) => data.count >= Math.max(3, threshold) && phrase.length > 15)
      .sort((a, b) => b[1].count - a[1].count)
      .slice(0, 5);

    if (repeatedPhrases.length === 0) return [];

    return [{
      type: 'phrase_repetition',
      title: `${repeatedPhrases.length} repeated phrase${repeatedPhrases.length !== 1 ? 's' : ''} detected`,
      explanation: `These phrases appear in multiple reviews, suggesting potential template use or coordinated language.`,
      confidence: Math.min(repeatedPhrases[0][1].count / reviewsWithText.length, 0.95),
      evidence: repeatedPhrases.flatMap(([phrase, data]) => 
        data.reviews.slice(0, 3).map(r => ({
          reviewId: r.id,
          snippet: phrase,
          metadata: { occurrences: data.count },
        }))
      ),
      evidenceSummary: {
        topPhrases: repeatedPhrases.map(([phrase, data]) => ({
          phrase,
          count: data.count,
          percentage: Math.round((data.count / reviewsWithText.length) * 100),
        })),
      },
    }];
  }

  /**
   * Detect incentive language
   */
  private detectIncentiveLanguage(reviews: any[]): DetectedSignal[] {
    const reviewsWithIncentives: Array<{ review: any; keywords: string[] }> = [];

    for (const review of reviews) {
      if (!review.text) continue;

      const textLower = review.text.toLowerCase();
      const foundKeywords = INCENTIVE_KEYWORDS.filter(kw => textLower.includes(kw));

      if (foundKeywords.length > 0) {
        reviewsWithIncentives.push({ review, keywords: foundKeywords });
      }
    }

    if (reviewsWithIncentives.length === 0) return [];

    return [{
      type: 'incentive_language',
      title: `${reviewsWithIncentives.length} review${reviewsWithIncentives.length !== 1 ? 's' : ''} mention incentives`,
      explanation: 'These reviews contain language suggesting they may have been written in exchange for compensation, discounts, or gifts.',
      confidence: 0.9,
      evidence: reviewsWithIncentives.map(({ review, keywords }) => {
        // Find snippet containing keyword
        const keyword = keywords[0];
        const index = review.text.toLowerCase().indexOf(keyword);
        const start = Math.max(0, index - 30);
        const end = Math.min(review.text.length, index + keyword.length + 30);
        const snippet = '...' + review.text.substring(start, end) + '...';

        return {
          reviewId: review.id,
          snippet,
          metadata: { keywords },
        };
      }),
    }];
  }

  // Helper: Build TF-IDF vector for a document
  private buildTFIDFVector(text: string, corpus: any[]): Map<string, number> {
    const words = this.tokenize(text);
    const wordCounts = new Map<string, number>();
    
    for (const word of words) {
      wordCounts.set(word, (wordCounts.get(word) || 0) + 1);
    }

    // Calculate TF-IDF
    const vector = new Map<string, number>();
    for (const [word, count] of wordCounts) {
      const tf = count / words.length;
      const docsWithWord = corpus.filter(doc => 
        doc.text && this.tokenize(doc.text).includes(word)
      ).length;
      const idf = Math.log(corpus.length / (docsWithWord + 1));
      vector.set(word, tf * idf);
    }

    return vector;
  }

  // Helper: Cosine similarity between vectors
  private cosineSimilarity(vec1: Map<string, number>, vec2: Map<string, number>): number {
    let dotProduct = 0;
    let mag1 = 0;
    let mag2 = 0;

    const allKeys = new Set([...vec1.keys(), ...vec2.keys()]);

    for (const key of allKeys) {
      const v1 = vec1.get(key) || 0;
      const v2 = vec2.get(key) || 0;
      dotProduct += v1 * v2;
      mag1 += v1 * v1;
      mag2 += v2 * v2;
    }

    if (mag1 === 0 || mag2 === 0) return 0;
    return dotProduct / (Math.sqrt(mag1) * Math.sqrt(mag2));
  }

  // Helper: Simple sentiment analysis (positive words vs negative words)
  private analyzeSentiment(text: string): number {
    const positiveWords = ['excellent', 'great', 'good', 'amazing', 'fantastic', 'brilliant', 'wonderful', 'perfect', 'best', 'love', 'highly recommend', 'satisfied', 'happy'];
    const negativeWords = ['terrible', 'awful', 'bad', 'poor', 'worst', 'horrible', 'disappointing', 'never', 'waste', 'rude', 'unprofessional', 'avoid'];

    const textLower = text.toLowerCase();
    let positiveCount = 0;
    let negativeCount = 0;

    for (const word of positiveWords) {
      if (textLower.includes(word)) positiveCount++;
    }

    for (const word of negativeWords) {
      if (textLower.includes(word)) negativeCount++;
    }

    const total = positiveCount + negativeCount;
    if (total === 0) return 0.5; // Neutral

    return positiveCount / total;
  }

  // Helper: Tokenize text
  private tokenize(text: string): string[] {
    return text
      .toLowerCase()
      .replace(/[^\w\s]/g, ' ')
      .split(/\s+/)
      .filter(w => w.length > 3);
  }

  // Helper: Extract n-grams
  private extractNGrams(text: string, minN: number, maxN: number): string[] {
    const words = text.toLowerCase().replace(/[^\w\s]/g, ' ').split(/\s+/);
    const ngrams: string[] = [];

    for (let n = minN; n <= maxN; n++) {
      for (let i = 0; i <= words.length - n; i++) {
        const ngram = words.slice(i, i + n).join(' ');
        if (ngram.length > 15) {
          ngrams.push(ngram);
        }
      }
    }

    return ngrams;
  }

  /**
   * Save detected signals to database
   */
  async saveSignals(businessId: string, signals: DetectedSignal[]): Promise<void> {
    // Delete existing signals for this business
    await prisma.signal.deleteMany({
      where: { businessId },
    });

    // Create new signals
    for (const signal of signals) {
      await prisma.signal.create({
        data: {
          businessId,
          type: signal.type,
          confidence: signal.confidence,
          title: signal.title,
          explanation: signal.explanation,
          evidenceSummary: signal.evidenceSummary || {},
          evidence: {
            create: signal.evidence.map(e => ({
              reviewId: e.reviewId,
              snippet: e.snippet,
            })),
          },
        },
      });
    }
  }
}
