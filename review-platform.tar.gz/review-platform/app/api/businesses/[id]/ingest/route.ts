import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { z } from 'zod';

const prisma = new PrismaClient();

const ingestSchema = z.object({
  profileId: z.string().optional(),
  source: z.string(),
  config: z.record(z.any()).optional(),
});

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const data = ingestSchema.parse(body);

    const job = await prisma.ingestJob.create({
      data: {
        profileId: data.profileId,
        source: data.source,
        status: 'pending',
        progress: { current: 0, total: 0, errors: [] },
        config: data.config || {},
      },
    });

    return NextResponse.json({ jobId: job.id });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: 'Invalid request', details: error.errors },
        { status: 400 }
      );
    }
    console.error('Create ingest job error:', error);
    return NextResponse.json({ error: 'Failed to create job' }, { status: 500 });
  }
}
