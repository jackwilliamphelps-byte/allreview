import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Ultimate Review Platform',
  description: 'Aggregate and analyse business reviews across multiple sources',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en-GB">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;500;600&family=Lora:wght@400;600&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="font-mono bg-neutral-950 text-neutral-100 antialiased">
        <div className="min-h-screen flex flex-col">
          <header className="border-b border-amber-600/30 bg-neutral-900/50 backdrop-blur">
            <div className="container mx-auto px-6 py-4">
              <div className="flex items-baseline justify-between">
                <div>
                  <h1 className="text-2xl font-semibold tracking-tight">
                    <span className="text-amber-500">REVIEW</span>
                    <span className="text-neutral-400">.ANALYSIS</span>
                  </h1>
                  <p className="text-xs text-neutral-500 mt-1">Multi-source aggregation platform</p>
                </div>
                <nav className="flex gap-6 text-sm">
                  <a href="/" className="text-neutral-400 hover:text-amber-500 transition-colors">
                    Search
                  </a>
                  <a href="/settings" className="text-neutral-400 hover:text-amber-500 transition-colors">
                    Settings
                  </a>
                </nav>
              </div>
            </div>
          </header>
          <main className="flex-1">
            {children}
          </main>
          <footer className="border-t border-amber-600/30 bg-neutral-900/50 backdrop-blur mt-auto">
            <div className="container mx-auto px-6 py-4">
              <div className="flex justify-between items-center text-xs text-neutral-600">
                <p>© 2026 Ultimate Review Platform</p>
                <p>Production MVP • Vercel Deployment</p>
              </div>
            </div>
          </footer>
        </div>
      </body>
    </html>
  );
}
