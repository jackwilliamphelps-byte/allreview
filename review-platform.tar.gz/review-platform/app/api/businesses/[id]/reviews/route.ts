import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const { searchParams } = new URL(request.url);
    const page = parseInt(searchParams.get('page') || '1');
    const limit = parseInt(searchParams.get('limit') || '50');
    const source = searchParams.get('source');
    const minRating = searchParams.get('minRating');
    const maxRating = searchParams.get('maxRating');

    const skip = (page - 1) * limit;

    const where: any = {
      profile: { businessId: params.id },
    };

    if (source) {
      where.profile = { ...where.profile, source };
    }

    if (minRating || maxRating) {
      where.ratingNormalised = {};
      if (minRating) where.ratingNormalised.gte = parseFloat(minRating);
      if (maxRating) where.ratingNormalised.lte = parseFloat(maxRating);
    }

    const [reviews, total] = await Promise.all([
      prisma.review.findMany({
        where,
        include: {
          profile: { select: { source: true, displayName: true } },
        },
        orderBy: { reviewDate: 'desc' },
        skip,
        take: limit,
      }),
      prisma.review.count({ where }),
    ]);

    return NextResponse.json({
      reviews,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    });
  } catch (error) {
    console.error('Get reviews error:', error);
    return NextResponse.json({ error: 'Failed to fetch reviews' }, { status: 500 });
  }
}
