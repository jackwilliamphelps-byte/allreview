'use client';

import { useState, useMemo } from 'react';
import { format } from 'date-fns';

interface Review {
  id: string;
  authorName?: string;
  authorId?: string;
  title?: string;
  text?: string;
  ratingNormalised: number;
  ratingOriginal: string;
  reviewDate: Date;
  verifiedPurchase: boolean;
  profile: {
    source: string;
    displayName: string;
  };
}

interface ReviewTableProps {
  reviews: Review[];
  onLoadMore?: () => void;
  hasMore?: boolean;
  loading?: boolean;
}

export default function ReviewTable({ reviews, onLoadMore, hasMore, loading }: ReviewTableProps) {
  const [sourceFilter, setSourceFilter] = useState<string>('all');
  const [ratingFilter, setRatingFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'date' | 'rating'>('date');
  const [searchQuery, setSearchQuery] = useState('');

  // Get unique sources
  const sources = useMemo(() => {
    const uniqueSources = new Set(reviews.map(r => r.profile.source));
    return Array.from(uniqueSources);
  }, [reviews]);

  // Filter and sort reviews
  const filteredReviews = useMemo(() => {
    let filtered = reviews;

    // Source filter
    if (sourceFilter !== 'all') {
      filtered = filtered.filter(r => r.profile.source === sourceFilter);
    }

    // Rating filter
    if (ratingFilter !== 'all') {
      const [min, max] = ratingFilter.split('-').map(Number);
      filtered = filtered.filter(r => r.ratingNormalised >= min && r.ratingNormalised <= max);
    }

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(r => 
        r.text?.toLowerCase().includes(query) ||
        r.title?.toLowerCase().includes(query) ||
        r.authorName?.toLowerCase().includes(query)
      );
    }

    // Sort
    const sorted = [...filtered].sort((a, b) => {
      if (sortBy === 'date') {
        return new Date(b.reviewDate).getTime() - new Date(a.reviewDate).getTime();
      } else {
        return b.ratingNormalised - a.ratingNormalised;
      }
    });

    return sorted;
  }, [reviews, sourceFilter, ratingFilter, searchQuery, sortBy]);

  const getRatingColor = (rating: number) => {
    if (rating >= 80) return 'text-emerald-500';
    if (rating >= 60) return 'text-amber-500';
    if (rating >= 40) return 'text-orange-500';
    return 'text-red-500';
  };

  const getStars = (rating: number) => {
    const stars = Math.round((rating / 100) * 5);
    return '★'.repeat(stars) + '☆'.repeat(5 - stars);
  };

  return (
    <div className="card">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <h3 className="text-lg font-semibold text-neutral-300">
          Reviews {filteredReviews.length !== reviews.length && `(${filteredReviews.length} of ${reviews.length})`}
        </h3>

        {/* Filters */}
        <div className="flex flex-wrap gap-2">
          {/* Search */}
          <input
            type="text"
            placeholder="Search reviews..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="input text-sm w-48"
          />

          {/* Source filter */}
          <select
            value={sourceFilter}
            onChange={(e) => setSourceFilter(e.target.value)}
            className="input text-sm w-36"
          >
            <option value="all">All Sources</option>
            {sources.map(source => (
              <option key={source} value={source}>
                {source.charAt(0).toUpperCase() + source.slice(1)}
              </option>
            ))}
          </select>

          {/* Rating filter */}
          <select
            value={ratingFilter}
            onChange={(e) => setRatingFilter(e.target.value)}
            className="input text-sm w-36"
          >
            <option value="all">All Ratings</option>
            <option value="80-100">80-100 (Excellent)</option>
            <option value="60-79">60-79 (Good)</option>
            <option value="40-59">40-59 (Fair)</option>
            <option value="0-39">0-39 (Poor)</option>
          </select>

          {/* Sort */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as 'date' | 'rating')}
            className="input text-sm w-36"
          >
            <option value="date">Newest First</option>
            <option value="rating">Highest Rated</option>
          </select>
        </div>
      </div>

      {/* Reviews list */}
      <div className="space-y-4">
        {filteredReviews.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-neutral-600 text-4xl mb-3">📭</div>
            <p className="text-neutral-400">No reviews match your filters</p>
          </div>
        ) : (
          filteredReviews.map((review, idx) => (
            <div 
              key={review.id} 
              className="border-b border-neutral-800 pb-4 last:border-0 hover:bg-neutral-800/30 -mx-4 px-4 py-3 rounded transition-colors"
            >
              <div className="flex items-start justify-between gap-4 mb-3">
                {/* Author & metadata */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-3 mb-1 flex-wrap">
                    <span className="text-sm font-medium text-neutral-200">
                      {review.authorName || 'Anonymous'}
                    </span>
                    <span className="badge badge-neutral text-xs">
                      {review.profile.source}
                    </span>
                    {review.verifiedPurchase && (
                      <span className="badge badge-success text-xs">✓ Verified</span>
                    )}
                  </div>
                  {review.title && (
                    <h4 className="text-sm font-medium text-neutral-300 mb-1 line-clamp-1">
                      {review.title}
                    </h4>
                  )}
                  <div className="text-xs text-neutral-500">
                    {format(new Date(review.reviewDate), 'PPP')}
                  </div>
                </div>

                {/* Rating */}
                <div className="text-right flex-shrink-0">
                  <div className={`text-2xl font-bold ${getRatingColor(review.ratingNormalised)} mb-1`}>
                    {review.ratingNormalised.toFixed(0)}
                  </div>
                  <div className="text-amber-500 text-xs tracking-wider">
                    {getStars(review.ratingNormalised)}
                  </div>
                </div>
              </div>

              {/* Review text */}
              {review.text && (
                <div className="prose-mono mt-3">
                  <p className="text-sm text-neutral-400 leading-relaxed">
                    {review.text}
                  </p>
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Load more */}
      {hasMore && onLoadMore && (
        <div className="mt-6 text-center">
          <button
            onClick={onLoadMore}
            disabled={loading}
            className="btn btn-secondary"
          >
            {loading ? (
              <span className="flex items-center gap-2">
                <svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Loading...
              </span>
            ) : (
              `Load More Reviews (${reviews.length} shown)`
            )}
          </button>
        </div>
      )}

      {/* Stats footer */}
      <div className="mt-6 pt-4 border-t border-neutral-800 flex justify-between text-xs text-neutral-500">
        <span>Showing {filteredReviews.length} reviews</span>
        {searchQuery && <span>Search: "{searchQuery}"</span>}
      </div>
    </div>
  );
}
