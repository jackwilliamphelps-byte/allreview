// Scoring service: Normalised ratings with recency weighting and confidence

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export interface ScoringConfig {
  halfLifeDays: number; // Recency decay half-life
  sourceWeights?: Record<string, number>; // Optional per-source weights
  minReviewsForConfidence: number; // Minimum reviews for high confidence
}

export interface ScoreResult {
  overallScore: number; // 0-100
  confidence: number; // 0-100
  confidenceExplanation: string;
  reviewCount: number;
  sourceBreakdown: SourceScore[];
  trend?: TrendData;
}

export interface SourceScore {
  source: string;
  profileId: string;
  displayName: string;
  score: number; // 0-100
  reviewCount: number;
  averageRating: number; // Original scale (e.g., 0-5)
  weight: number; // Applied weight
}

export interface TrendData {
  direction: 'up' | 'down' | 'stable';
  change: number; // Percentage change
  recentAverage: number; // Last 30 days
  previousAverage: number; // Previous 30 days
}

const DEFAULT_CONFIG: ScoringConfig = {
  halfLifeDays: 90,
  minReviewsForConfidence: 20,
  sourceWeights: {
    trustpilot: 1.0,
    google: 1.0,
    feefo: 1.0,
    csv_import: 0.8, // Slightly lower weight for uploaded data
  },
};

export class ScoringService {
  private config: ScoringConfig;

  constructor(config: Partial<ScoringConfig> = {}) {
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  /**
   * Calculate comprehensive score for a business
   */
  async calculateBusinessScore(businessId: string): Promise<ScoreResult> {
    // Fetch all reviews for this business
    const profiles = await prisma.profile.findMany({
      where: { businessId },
      include: {
        reviews: {
          orderBy: { reviewDate: 'desc' },
        },
      },
    });

    if (profiles.length === 0 || profiles.every(p => p.reviews.length === 0)) {
      return {
        overallScore: 0,
        confidence: 0,
        confidenceExplanation: 'No reviews available',
        reviewCount: 0,
        sourceBreakdown: [],
      };
    }

    const now = new Date();
    const allReviews = profiles.flatMap(p => 
      p.reviews.map(r => ({
        ...r,
        profile: p,
      }))
    );

    // Calculate per-source scores
    const sourceBreakdown: SourceScore[] = profiles.map(profile => {
      const reviews = profile.reviews;
      if (reviews.length === 0) {
        return {
          source: profile.source,
          profileId: profile.id,
          displayName: profile.displayName,
          score: 0,
          reviewCount: 0,
          averageRating: 0,
          weight: 0,
        };
      }

      const weightedSum = reviews.reduce((sum, review) => {
        const weight = this.calculateRecencyWeight(review.reviewDate, now);
        return sum + review.ratingNormalised * weight;
      }, 0);

      const totalWeight = reviews.reduce((sum, review) => {
        return sum + this.calculateRecencyWeight(review.reviewDate, now);
      }, 0);

      const score = weightedSum / totalWeight;
      const sourceWeight = this.config.sourceWeights?.[profile.source] || 1.0;

      return {
        source: profile.source,
        profileId: profile.id,
        displayName: profile.displayName,
        score,
        reviewCount: reviews.length,
        averageRating: score / 20, // Convert to 0-5 scale for display
        weight: sourceWeight,
      };
    }).filter(s => s.reviewCount > 0);

    // Calculate overall weighted score
    const overallScore = this.calculateWeightedAverage(sourceBreakdown);

    // Calculate confidence
    const { confidence, explanation } = this.calculateConfidence(
      allReviews.map(r => r.ratingNormalised),
      allReviews.length
    );

    // Calculate trend
    const trend = this.calculateTrend(allReviews);

    return {
      overallScore,
      confidence,
      confidenceExplanation: explanation,
      reviewCount: allReviews.length,
      sourceBreakdown,
      trend,
    };
  }

  /**
   * Calculate recency weight using exponential decay
   * weight = exp(-ln(2) * days_old / half_life)
   */
  private calculateRecencyWeight(reviewDate: Date, now: Date): number {
    const daysOld = (now.getTime() - reviewDate.getTime()) / (1000 * 60 * 60 * 24);
    const weight = Math.exp(-Math.LN2 * daysOld / this.config.halfLifeDays);
    return weight;
  }

  /**
   * Calculate weighted average across sources
   */
  private calculateWeightedAverage(sourceBreakdown: SourceScore[]): number {
    if (sourceBreakdown.length === 0) return 0;

    const weightedSum = sourceBreakdown.reduce((sum, source) => {
      return sum + source.score * source.weight * source.reviewCount;
    }, 0);

    const totalWeight = sourceBreakdown.reduce((sum, source) => {
      return sum + source.weight * source.reviewCount;
    }, 0);

    return weightedSum / totalWeight;
  }

  /**
   * Calculate confidence score using sample size and variance
   * Uses Wilson score interval approach
   */
  private calculateConfidence(
    ratings: number[],
    count: number
  ): { confidence: number; explanation: string } {
    if (count === 0) {
      return {
        confidence: 0,
        explanation: 'No reviews available',
      };
    }

    if (count < 5) {
      return {
        confidence: 20,
        explanation: `Very low confidence: Only ${count} review${count !== 1 ? 's' : ''} available. More data needed for reliable score.`,
      };
    }

    if (count < this.config.minReviewsForConfidence) {
      return {
        confidence: 40 + (count / this.config.minReviewsForConfidence) * 30,
        explanation: `Moderate confidence: ${count} reviews. Score becomes more reliable with ${this.config.minReviewsForConfidence}+ reviews.`,
      };
    }

    // Calculate variance
    const mean = ratings.reduce((sum, r) => sum + r, 0) / ratings.length;
    const variance = ratings.reduce((sum, r) => sum + Math.pow(r - mean, 2), 0) / ratings.length;
    const stdDev = Math.sqrt(variance);

    // Normalize std dev (max is 50 for 0-100 scale with uniform distribution)
    const normalizedStdDev = stdDev / 50;

    // Higher variance = lower confidence
    const variancePenalty = normalizedStdDev * 20;

    // Sample size boost (logarithmic)
    const sampleBoost = Math.min(10, Math.log10(count) * 5);

    const confidence = Math.min(100, 70 + sampleBoost - variancePenalty);

    let explanation = `High confidence: ${count} reviews`;
    if (stdDev > 30) {
      explanation += ' with high variance (mixed opinions)';
    } else if (stdDev < 15) {
      explanation += ' with consistent ratings';
    }

    return { confidence, explanation };
  }

  /**
   * Calculate score trend over time
   */
  private calculateTrend(reviews: Array<{ reviewDate: Date; ratingNormalised: number }>): TrendData {
    const now = new Date();
    const thirtyDaysAgo = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    const sixtyDaysAgo = new Date(now.getTime() - 60 * 24 * 60 * 60 * 1000);

    const recentReviews = reviews.filter(r => r.reviewDate >= thirtyDaysAgo);
    const previousReviews = reviews.filter(r => 
      r.reviewDate >= sixtyDaysAgo && r.reviewDate < thirtyDaysAgo
    );

    if (recentReviews.length === 0) {
      return {
        direction: 'stable',
        change: 0,
        recentAverage: 0,
        previousAverage: 0,
      };
    }

    const recentAverage = recentReviews.reduce((sum, r) => sum + r.ratingNormalised, 0) / recentReviews.length;
    const previousAverage = previousReviews.length > 0
      ? previousReviews.reduce((sum, r) => sum + r.ratingNormalised, 0) / previousReviews.length
      : recentAverage;

    const change = ((recentAverage - previousAverage) / previousAverage) * 100;

    let direction: 'up' | 'down' | 'stable';
    if (Math.abs(change) < 5) {
      direction = 'stable';
    } else if (change > 0) {
      direction = 'up';
    } else {
      direction = 'down';
    }

    return {
      direction,
      change,
      recentAverage,
      previousAverage,
    };
  }

  /**
   * Save score snapshot to database for historical tracking
   */
  async saveSnapshot(businessId: string, result: ScoreResult): Promise<void> {
    await prisma.scoreSnapshot.create({
      data: {
        businessId,
        overallScore: result.overallScore,
        confidence: result.confidence,
        reviewCount: result.reviewCount,
        sourceBreakdown: result.sourceBreakdown.reduce((acc, s) => {
          acc[s.source] = s.score;
          return acc;
        }, {} as Record<string, number>),
        halfLifeDays: this.config.halfLifeDays,
      },
    });
  }
}
