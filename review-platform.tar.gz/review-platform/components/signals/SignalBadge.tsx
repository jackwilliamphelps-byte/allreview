'use client';

import { useState } from 'react';

interface SignalBadgeProps {
  type: string;
  title: string;
  confidence: number;
  explanation: string;
  evidence?: Array<{
    reviewId: string;
    snippet?: string;
    metadata?: Record<string, any>;
  }>;
  evidenceSummary?: Record<string, any>;
}

const signalConfig: Record<string, { 
  icon: string; 
  colorClass: string; 
  bgClass: string;
  description: string;
}> = {
  similarity_cluster: { 
    icon: '🔄', 
    colorClass: 'text-amber-500 border-amber-600/30', 
    bgClass: 'bg-amber-600/20',
    description: 'Reviews with suspiciously similar text patterns'
  },
  burst: { 
    icon: '📈', 
    colorClass: 'text-orange-500 border-orange-600/30', 
    bgClass: 'bg-orange-600/20',
    description: 'Unusual spike in review volume'
  },
  rating_mismatch: { 
    icon: '⚠️', 
    colorClass: 'text-red-500 border-red-600/30', 
    bgClass: 'bg-red-600/20',
    description: 'Star rating contradicts review text sentiment'
  },
  phrase_repetition: { 
    icon: '💬', 
    colorClass: 'text-yellow-500 border-yellow-600/30', 
    bgClass: 'bg-yellow-600/20',
    description: 'Identical phrases repeated across reviews'
  },
  incentive_language: { 
    icon: '💰', 
    colorClass: 'text-red-500 border-red-600/30', 
    bgClass: 'bg-red-600/20',
    description: 'Language suggesting compensated reviews'
  },
};

export default function SignalBadge({ 
  type, 
  title, 
  confidence, 
  explanation,
  evidence = [],
  evidenceSummary
}: SignalBadgeProps) {
  const [showModal, setShowModal] = useState(false);
  const config = signalConfig[type] || { 
    icon: '🔍', 
    colorClass: 'text-neutral-400 border-neutral-700', 
    bgClass: 'bg-neutral-800',
    description: 'Suspicious pattern detected'
  };

  return (
    <>
      <button
        onClick={() => setShowModal(true)}
        className={`badge ${config.colorClass} ${config.bgClass} flex items-center gap-2 hover:scale-105 transition-transform cursor-pointer`}
      >
        <span>{config.icon}</span>
        <span className="font-medium">{title}</span>
        <span className="text-xs opacity-75">{Math.round(confidence * 100)}%</span>
      </button>

      {/* Modal */}
      {showModal && (
        <div 
          className="fixed inset-0 bg-neutral-950/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={() => setShowModal(false)}
        >
          <div 
            className="card max-w-3xl w-full max-h-[80vh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-6">
              <div className="flex items-start gap-4">
                <div className="text-3xl">{config.icon}</div>
                <div>
                  <h3 className="text-xl font-bold text-neutral-100 mb-1">{title}</h3>
                  <p className="text-sm text-neutral-400">{config.description}</p>
                </div>
              </div>
              <button
                onClick={() => setShowModal(false)}
                className="text-neutral-500 hover:text-neutral-300 transition-colors"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            {/* Confidence */}
            <div className="mb-6 p-4 bg-neutral-800/50 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-neutral-400">Confidence Level</span>
                <span className="text-lg font-bold text-amber-500">
                  {Math.round(confidence * 100)}%
                </span>
              </div>
              <div className="w-full bg-neutral-800 rounded-full h-2">
                <div
                  className="h-2 rounded-full bg-amber-600 transition-all duration-500"
                  style={{ width: `${confidence * 100}%` }}
                />
              </div>
            </div>

            {/* Explanation */}
            <div className="mb-6">
              <h4 className="text-sm font-semibold text-neutral-300 mb-2 uppercase tracking-wide">
                What This Means
              </h4>
              <p className="text-neutral-400 leading-relaxed">{explanation}</p>
            </div>

            {/* Evidence Summary */}
            {evidenceSummary && Object.keys(evidenceSummary).length > 0 && (
              <div className="mb-6">
                <h4 className="text-sm font-semibold text-neutral-300 mb-3 uppercase tracking-wide">
                  Statistics
                </h4>
                <div className="grid grid-cols-2 gap-3">
                  {Object.entries(evidenceSummary).map(([key, value]) => (
                    <div key={key} className="p-3 bg-neutral-800/50 rounded">
                      <div className="text-xs text-neutral-500 mb-1">
                        {key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase())}
                      </div>
                      <div className="text-neutral-200 font-semibold">
                        {typeof value === 'object' ? JSON.stringify(value) : String(value)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Evidence */}
            {evidence.length > 0 && (
              <div>
                <h4 className="text-sm font-semibold text-neutral-300 mb-3 uppercase tracking-wide">
                  Evidence ({evidence.length} reviews)
                </h4>
                <div className="space-y-3 max-h-64 overflow-y-auto">
                  {evidence.map((item, idx) => (
                    <div key={idx} className="p-3 bg-neutral-800/50 rounded hover:bg-neutral-800 transition-colors">
                      {item.snippet && (
                        <p className="text-sm text-neutral-300 mb-2">"{item.snippet}"</p>
                      )}
                      {item.metadata && Object.keys(item.metadata).length > 0 && (
                        <div className="flex gap-2 text-xs text-neutral-500">
                          {Object.entries(item.metadata).map(([key, value]) => (
                            <span key={key}>
                              {key}: <span className="text-neutral-400">{String(value)}</span>
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Footer */}
            <div className="mt-6 pt-4 border-t border-neutral-800 text-xs text-neutral-500">
              ⚠️ These are signals consistent with suspicious patterns, not definitive proof of fraud.
              Manual review recommended.
            </div>
          </div>
        </div>
      )}
    </>
  );
}
