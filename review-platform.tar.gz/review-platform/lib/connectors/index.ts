// Connector registry - central management of all source connectors

import { SourceConnector } from './types';
import { TrustpilotDemoConnector } from './trustpilot-demo';
import { CSVImportConnector } from './csv-import';

// Registry of all available connectors
const connectors = new Map<string, SourceConnector>();

// Initialize built-in connectors
export function initializeConnectors() {
  if (connectors.size > 0) return; // Already initialized

  // Register demo connector
  registerConnector(new TrustpilotDemoConnector());
  
  // CSV import is registered per-use with configuration
  // registerConnector(new CSVImportConnector());
}

// Register a connector
export function registerConnector(connector: SourceConnector) {
  connectors.set(connector.source, connector);
}

// Get a specific connector
export function getConnector(source: string): SourceConnector | undefined {
  initializeConnectors();
  return connectors.get(source);
}

// Get all registered connectors
export function getAllConnectors(): SourceConnector[] {
  initializeConnectors();
  return Array.from(connectors.values());
}

// Check if a connector is available
export function hasConnector(source: string): boolean {
  initializeConnectors();
  return connectors.has(source);
}

// List available sources
export function listSources(): string[] {
  initializeConnectors();
  return Array.from(connectors.keys());
}

// Export connector classes for direct instantiation
export { TrustpilotDemoConnector, CSVImportConnector };
export * from './types';
