// Demo connector for Trustpilot
// Simulates API responses using seeded database data

import { PrismaClient } from '@prisma/client';
import {
  SourceConnector,
  SearchQuery,
  ProfileMatch,
  ReviewData,
  ProfileSummary,
  PaginationParams,
  PaginatedResult,
} from './types';

const prisma = new PrismaClient();

export class TrustpilotDemoConnector implements SourceConnector {
  readonly name = 'Trustpilot (Demo)';
  readonly source = 'trustpilot';

  async searchProfiles(query: SearchQuery): Promise<ProfileMatch[]> {
    // In real implementation, this would call Trustpilot API
    // For demo, search our seeded profiles
    
    const whereClause: any = {
      source: 'trustpilot',
    };

    if (query.businessName) {
      whereClause.OR = [
        { displayName: { contains: query.businessName, mode: 'insensitive' } },
        { business: { name: { contains: query.businessName, mode: 'insensitive' } } },
      ];
    }

    const profiles = await prisma.profile.findMany({
      where: whereClause,
      include: {
        business: true,
      },
      take: 10,
    });

    return profiles.map(profile => ({
      externalId: profile.externalId,
      externalUrl: profile.externalUrl || undefined,
      displayName: profile.displayName,
      claimedStatus: profile.claimedStatus as 'claimed' | 'unclaimed' | 'unknown',
      matchConfidence: profile.matchConfidence,
      metadata: {
        businessName: profile.business.name,
        location: {
          city: profile.business.city,
          postcode: profile.business.postcode,
        },
      },
    }));
  }

  async fetchReviews(
    profileRef: { externalId: string },
    pagination?: PaginationParams
  ): Promise<PaginatedResult<ReviewData>> {
    const limit = pagination?.limit || 50;
    const page = pagination?.page || 1;
    const skip = (page - 1) * limit;

    // Find profile
    const profile = await prisma.profile.findUnique({
      where: {
        source_externalId: {
          source: 'trustpilot',
          externalId: profileRef.externalId,
        },
      },
    });

    if (!profile) {
      return {
        data: [],
        pagination: { hasMore: false },
      };
    }

    // Fetch reviews
    const [reviews, total] = await Promise.all([
      prisma.review.findMany({
        where: { profileId: profile.id },
        orderBy: { reviewDate: 'desc' },
        skip,
        take: limit,
      }),
      prisma.review.count({
        where: { profileId: profile.id },
      }),
    ]);

    return {
      data: reviews.map(review => ({
        externalId: review.externalId,
        authorName: review.authorName || undefined,
        authorId: review.authorId || undefined,
        title: review.title || undefined,
        text: review.text || undefined,
        ratingOriginal: review.ratingOriginal,
        ratingNormalised: review.ratingNormalised,
        ratingType: review.ratingType as any,
        reviewDate: review.reviewDate,
        verifiedPurchase: review.verifiedPurchase,
        metadata: review.metadata as Record<string, any> | undefined,
      })),
      pagination: {
        hasMore: skip + reviews.length < total,
        total,
      },
    };
  }

  async fetchSummary(profileRef: { externalId: string }): Promise<ProfileSummary | null> {
    const profile = await prisma.profile.findUnique({
      where: {
        source_externalId: {
          source: 'trustpilot',
          externalId: profileRef.externalId,
        },
      },
    });

    if (!profile) return null;

    const reviews = await prisma.review.findMany({
      where: { profileId: profile.id },
      select: {
        ratingNormalised: true,
        reviewDate: true,
      },
    });

    if (reviews.length === 0) return null;

    const avgRating = reviews.reduce((sum, r) => sum + r.ratingNormalised, 0) / reviews.length;
    const latestDate = reviews.reduce((max, r) => 
      r.reviewDate > max ? r.reviewDate : max, 
      reviews[0].reviewDate
    );

    return {
      totalReviews: reviews.length,
      averageRating: avgRating / 20, // Convert 0-100 back to 0-5
      lastReviewDate: latestDate,
    };
  }

  async testConnection(): Promise<{ success: boolean; message: string }> {
    try {
      await prisma.profile.findFirst({
        where: { source: 'trustpilot' },
      });
      return {
        success: true,
        message: 'Demo connector operational',
      };
    } catch (error) {
      return {
        success: false,
        message: 'Database connection failed',
      };
    }
  }
}
