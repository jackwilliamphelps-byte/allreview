// CSV Import Connector
// Universal connector for importing reviews from CSV files

import Papa from 'papaparse';
import {
  SourceConnector,
  SearchQuery,
  ProfileMatch,
  ReviewData,
  ProfileSummary,
  PaginationParams,
  PaginatedResult,
  normaliseRating,
  detectRatingType,
} from './types';

export interface CSVImportConfig {
  file: File | string; // File object or CSV string
  mapping: {
    externalId?: string;
    authorName?: string;
    title?: string;
    text?: string;
    rating?: string;
    date?: string;
    verifiedPurchase?: string;
  };
  source?: string; // Override source name
  profileExternalId?: string; // Link to specific profile
}

export class CSVImportConnector implements SourceConnector {
  readonly name = 'CSV Import';
  readonly source = 'csv_import';
  
  private config?: CSVImportConfig;
  private cachedData?: ReviewData[];

  constructor(config?: CSVImportConfig) {
    this.config = config;
  }

  // CSV import doesn't support profile search
  async searchProfiles(query: SearchQuery): Promise<ProfileMatch[]> {
    return [];
  }

  async fetchReviews(
    profileRef: { externalId: string },
    pagination?: PaginationParams
  ): Promise<PaginatedResult<ReviewData>> {
    if (!this.config) {
      throw new Error('CSV import requires configuration');
    }

    // Parse CSV if not cached
    if (!this.cachedData) {
      this.cachedData = await this.parseCSV();
    }

    const limit = pagination?.limit || 50;
    const page = pagination?.page || 1;
    const skip = (page - 1) * limit;

    const data = this.cachedData.slice(skip, skip + limit);

    return {
      data,
      pagination: {
        hasMore: skip + data.length < this.cachedData.length,
        total: this.cachedData.length,
      },
    };
  }

  async fetchSummary(profileRef: { externalId: string }): Promise<ProfileSummary | null> {
    if (!this.cachedData) {
      this.cachedData = await this.parseCSV();
    }

    if (this.cachedData.length === 0) return null;

    const avgRating = this.cachedData.reduce((sum, r) => sum + r.ratingNormalised, 0) / this.cachedData.length;
    const latestDate = this.cachedData.reduce((max, r) => 
      r.reviewDate > max ? r.reviewDate : max, 
      this.cachedData[0].reviewDate
    );

    return {
      totalReviews: this.cachedData.length,
      averageRating: avgRating,
      lastReviewDate: latestDate,
    };
  }

  private async parseCSV(): Promise<ReviewData[]> {
    if (!this.config) {
      throw new Error('CSV import requires configuration');
    }

    const csvContent = typeof this.config.file === 'string' 
      ? this.config.file 
      : await this.config.file.text();

    return new Promise((resolve, reject) => {
      Papa.parse(csvContent, {
        header: true,
        skipEmptyLines: true,
        complete: (results) => {
          try {
            const reviews = results.data.map((row: any, idx: number) => {
              const mapping = this.config!.mapping;
              
              // Extract fields based on mapping
              const ratingOriginal = mapping.rating ? String(row[mapping.rating] || '5') : '5';
              const ratingType = detectRatingType(ratingOriginal);
              const ratingNormalised = normaliseRating(ratingOriginal, ratingType);
              
              const dateStr = mapping.date ? row[mapping.date] : new Date().toISOString();
              const reviewDate = new Date(dateStr);
              
              return {
                externalId: mapping.externalId ? String(row[mapping.externalId]) : `csv-${idx}`,
                authorName: mapping.authorName ? row[mapping.authorName] : undefined,
                title: mapping.title ? row[mapping.title] : undefined,
                text: mapping.text ? row[mapping.text] : undefined,
                ratingOriginal,
                ratingNormalised,
                ratingType,
                reviewDate: isNaN(reviewDate.getTime()) ? new Date() : reviewDate,
                verifiedPurchase: mapping.verifiedPurchase 
                  ? ['true', 'yes', '1'].includes(String(row[mapping.verifiedPurchase]).toLowerCase())
                  : false,
                metadata: {
                  source: this.config?.source || 'csv_import',
                  rawRow: row,
                },
              };
            });

            resolve(reviews);
          } catch (error) {
            reject(error);
          }
        },
        error: (error) => {
          reject(error);
        },
      });
    });
  }

  async testConnection(): Promise<{ success: boolean; message: string }> {
    return {
      success: true,
      message: 'CSV import always available',
    };
  }

  // Static helper: Auto-detect column mapping from CSV headers
  static async detectMapping(csvContent: string): Promise<CSVImportConfig['mapping']> {
    return new Promise((resolve) => {
      Papa.parse(csvContent, {
        header: true,
        preview: 1,
        complete: (results) => {
          const headers = results.meta.fields || [];
          const mapping: CSVImportConfig['mapping'] = {};

          // Auto-detect common patterns
          const headerMap: Record<string, string[]> = {
            externalId: ['id', 'review_id', 'reviewid', 'external_id'],
            authorName: ['author', 'name', 'customer', 'reviewer', 'author_name'],
            title: ['title', 'subject', 'heading'],
            text: ['text', 'review', 'comment', 'content', 'body', 'description'],
            rating: ['rating', 'stars', 'score', 'rate'],
            date: ['date', 'created', 'review_date', 'posted', 'timestamp'],
            verifiedPurchase: ['verified', 'verified_purchase', 'verified_buyer'],
          };

          for (const [field, patterns] of Object.entries(headerMap)) {
            const match = headers.find(h => 
              patterns.some(p => h.toLowerCase().includes(p))
            );
            if (match) {
              mapping[field as keyof typeof mapping] = match;
            }
          }

          resolve(mapping);
        },
      });
    });
  }
}
