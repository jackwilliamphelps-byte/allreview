'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import ScoreCard from '@/components/business/ScoreCard';
import SourceBreakdown from '@/components/business/SourceBreakdown';
import ReviewTable from '@/components/business/ReviewTable';
import SignalBadge from '@/components/signals/SignalBadge';

export default function BusinessDetailPage() {
  const params = useParams();
  const router = useRouter();
  const [business, setBusiness] = useState<any>(null);
  const [score, setScore] = useState<any>(null);
  const [reviews, setReviews] = useState<any[]>([]);
  const [signals, setSignals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'overview' | 'reviews' | 'signals'>('overview');

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);

      try {
        // Fetch all data in parallel
        const [businessRes, scoreRes, reviewsRes, signalsRes] = await Promise.all([
          fetch(`/api/businesses/${params.id}`),
          fetch(`/api/businesses/${params.id}/score`),
          fetch(`/api/businesses/${params.id}/reviews?limit=100`),
          fetch(`/api/businesses/${params.id}/signals`),
        ]);

        if (!businessRes.ok) throw new Error('Business not found');

        const [businessData, scoreData, reviewsData, signalsData] = await Promise.all([
          businessRes.json(),
          scoreRes.json(),
          reviewsRes.json(),
          signalsRes.json(),
        ]);

        setBusiness(businessData);
        setScore(scoreData);
        setReviews(reviewsData.reviews || []);
        setSignals(signalsData.signals || []);
      } catch (error) {
        console.error('Failed to fetch business data:', error);
        setError(error instanceof Error ? error.message : 'Failed to load business');
      } finally {
        setLoading(false);
      }
    };

    if (params.id) {
      fetchData();
    }
  }, [params.id]);

  // Loading state
  if (loading) {
    return (
      <div className="container mx-auto px-6 py-12">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse space-y-8">
            <div className="h-12 bg-neutral-800 rounded w-1/3"></div>
            <div className="h-64 bg-neutral-800 rounded"></div>
            <div className="grid md:grid-cols-2 gap-6">
              <div className="h-48 bg-neutral-800 rounded"></div>
              <div className="h-48 bg-neutral-800 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Error state
  if (error || !business || !score) {
    return (
      <div className="container mx-auto px-6 py-12">
        <div className="max-w-6xl mx-auto text-center">
          <div className="text-6xl mb-4">😞</div>
          <h2 className="text-2xl font-bold text-neutral-300 mb-4">
            {error || 'Business not found'}
          </h2>
          <button onClick={() => router.push('/')} className="btn btn-primary">
            Return Home
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-6 py-12">
      <div className="max-w-6xl mx-auto">
        {/* Breadcrumb */}
        <nav className="mb-6 text-sm">
          <ol className="flex items-center gap-2 text-neutral-500">
            <li>
              <a href="/" className="hover:text-amber-500 transition-colors">Home</a>
            </li>
            <li>/</li>
            <li className="text-neutral-300">{business.name}</li>
          </ol>
        </nav>

        {/* Header */}
        <div className="mb-8">
          <div className="flex items-start justify-between mb-4">
            <div className="flex-1">
              <h1 className="text-4xl font-bold text-neutral-100 mb-3">{business.name}</h1>
              {business.description && (
                <p className="text-neutral-400 text-lg mb-3">{business.description}</p>
              )}
              <div className="flex flex-wrap gap-4 text-sm text-neutral-500">
                {business.website && (
                  <a
                    href={business.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 text-amber-500 hover:text-amber-400 transition-colors"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                    </svg>
                    {business.website.replace(/^https?:\/\//, '')}
                  </a>
                )}
                {business.city && (
                  <span className="flex items-center gap-1">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                    </svg>
                    {business.city}, {business.postcode}
                  </span>
                )}
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <button className="btn btn-secondary text-sm">
                Export Report
              </button>
            </div>
          </div>
        </div>

        {/* Signals Alert */}
        {signals.length > 0 && (
          <div className="card border-amber-600/30 bg-amber-600/5 mb-8">
            <div className="flex items-start gap-4">
              <div className="text-3xl flex-shrink-0">⚠️</div>
              <div className="flex-1">
                <h3 className="text-lg font-semibold text-neutral-200 mb-3">
                  {signals.length} Suspicious Signal{signals.length !== 1 ? 's' : ''} Detected
                </h3>
                <div className="flex flex-wrap gap-2 mb-3">
                  {signals.slice(0, 3).map((signal, idx) => (
                    <SignalBadge
                      key={idx}
                      type={signal.type}
                      title={signal.title}
                      confidence={signal.confidence}
                      explanation={signal.explanation}
                      evidence={signal.evidence}
                      evidenceSummary={signal.evidenceSummary}
                    />
                  ))}
                  {signals.length > 3 && (
                    <button
                      onClick={() => setActiveTab('signals')}
                      className="badge badge-neutral hover:bg-neutral-700 transition-colors"
                    >
                      +{signals.length - 3} more
                    </button>
                  )}
                </div>
                <p className="text-sm text-neutral-400">
                  These signals are consistent with suspicious review patterns. Click each badge for detailed evidence and analysis.
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="border-b border-neutral-800 mb-8">
          <nav className="flex gap-6">
            {(['overview', 'reviews', 'signals'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`pb-3 px-2 text-sm font-medium transition-colors border-b-2 ${
                  activeTab === tab
                    ? 'border-amber-500 text-amber-500'
                    : 'border-transparent text-neutral-400 hover:text-neutral-300'
                }`}
              >
                {tab.charAt(0).toUpperCase() + tab.slice(1)}
                {tab === 'signals' && signals.length > 0 && (
                  <span className="ml-2 px-2 py-0.5 bg-amber-600/20 text-amber-500 rounded text-xs">
                    {signals.length}
                  </span>
                )}
              </button>
            ))}
          </nav>
        </div>

        {/* Tab Content */}
        {activeTab === 'overview' && (
          <div className="space-y-8">
            {/* Score Dashboard */}
            <div className="grid md:grid-cols-2 gap-6">
              <ScoreCard
                score={score.overallScore}
                confidence={score.confidence}
                confidenceExplanation={score.confidenceExplanation}
                reviewCount={score.reviewCount}
                trend={score.trend}
              />
              <SourceBreakdown sources={score.sourceBreakdown} />
            </div>

            {/* Profiles */}
            <div className="card">
              <h3 className="section-title">Connected Profiles</h3>
              <div className="space-y-3">
                {business.profiles.map((profile: any) => (
                  <div
                    key={profile.id}
                    className="flex items-center justify-between p-4 bg-neutral-800/50 rounded-lg hover:bg-neutral-800 transition-colors"
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-sm font-medium text-neutral-200">
                          {profile.displayName}
                        </span>
                        {profile.matchConfidence < 1.0 && (
                          <span className="text-xs text-neutral-500">
                            ({Math.round(profile.matchConfidence * 100)}% match)
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-3 text-xs text-neutral-500">
                        <span className="badge badge-neutral">{profile.source}</span>
                        <span>{profile._count.reviews} reviews</span>
                        <span>•</span>
                        <span>Added via {profile.discoveryMethod}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {profile.claimedStatus === 'claimed' && (
                        <span className="badge badge-success text-xs">✓ Claimed</span>
                      )}
                      {profile.claimedStatus === 'unclaimed' && (
                        <span className="badge badge-warning text-xs">⚠ Unclaimed</span>
                      )}
                      {profile.externalUrl && (
                        <a
                          href={profile.externalUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-amber-500 hover:text-amber-400 text-sm flex items-center gap-1"
                        >
                          View
                          <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                          </svg>
                        </a>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Reviews Preview */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-neutral-300">Recent Reviews</h3>
                <button
                  onClick={() => setActiveTab('reviews')}
                  className="text-sm text-amber-500 hover:text-amber-400 transition-colors"
                >
                  View All →
                </button>
              </div>
              <ReviewTable reviews={reviews.slice(0, 5)} />
            </div>
          </div>
        )}

        {activeTab === 'reviews' && (
          <ReviewTable reviews={reviews} />
        )}

        {activeTab === 'signals' && (
          <div className="space-y-6">
            {signals.length === 0 ? (
              <div className="card text-center py-12">
                <div className="text-6xl mb-4">✓</div>
                <h3 className="text-xl font-semibold text-neutral-300 mb-2">
                  No Suspicious Signals Detected
                </h3>
                <p className="text-neutral-400">
                  Reviews appear to be genuine based on our pattern analysis.
                </p>
              </div>
            ) : (
              signals.map((signal, idx) => (
                <div key={idx} className="card">
                  <div className="flex items-start gap-4 mb-4">
                    <div className="text-3xl">
                      {signal.type === 'similarity_cluster' && '🔄'}
                      {signal.type === 'burst' && '📈'}
                      {signal.type === 'rating_mismatch' && '⚠️'}
                      {signal.type === 'phrase_repetition' && '💬'}
                      {signal.type === 'incentive_language' && '💰'}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h4 className="text-lg font-semibold text-neutral-200">
                          {signal.title}
                        </h4>
                        <span className="badge badge-warning">
                          {Math.round(signal.confidence * 100)}% confidence
                        </span>
                      </div>
                      <p className="text-neutral-400 mb-4">{signal.explanation}</p>
                      
                      {signal.evidenceSummary && (
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
                          {Object.entries(signal.evidenceSummary).map(([key, value]) => (
                            <div key={key} className="p-3 bg-neutral-800/50 rounded">
                              <div className="text-xs text-neutral-500 mb-1">
                                {key.replace(/_/g, ' ').toUpperCase()}
                              </div>
                              <div className="text-neutral-200 font-semibold">
                                {typeof value === 'object' ? JSON.stringify(value) : String(value)}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {signal.evidence && signal.evidence.length > 0 && (
                        <SignalBadge
                          type={signal.type}
                          title={`View ${signal.evidence.length} Evidence Items`}
                          confidence={signal.confidence}
                          explanation={signal.explanation}
                          evidence={signal.evidence}
                          evidenceSummary={signal.evidenceSummary}
                        />
                      )}
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        )}
      </div>
    </div>
  );
}
