'use client';

import { useEffect, useState } from 'react';

interface Source {
  source: string;
  name: string;
  enabled: boolean;
  status: string;
}

export default function SettingsPage() {
  const [sources, setSources] = useState<Source[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [uploadStatus, setUploadStatus] = useState<{ type: 'success' | 'error'; message: string } | null>(null);

  useEffect(() => {
    fetchSources();
  }, []);

  const fetchSources = async () => {
    try {
      const response = await fetch('/api/sources');
      const data = await response.json();
      setSources(data.sources || []);
    } catch (error) {
      console.error('Failed to fetch sources:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCSVUpload = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setUploading(true);
    setUploadStatus(null);

    const formData = new FormData(e.currentTarget);

    try {
      const response = await fetch('/api/import/csv', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (response.ok) {
        setUploadStatus({
          type: 'success',
          message: `Successfully imported ${data.reviewCount} reviews!`,
        });
        (e.target as HTMLFormElement).reset();
      } else {
        throw new Error(data.error || 'Upload failed');
      }
    } catch (error) {
      setUploadStatus({
        type: 'error',
        message: error instanceof Error ? error.message : 'Upload failed',
      });
    } finally {
      setUploading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    if (status === 'active') return 'badge-success';
    if (status === 'error') return 'badge-danger';
    return 'badge-neutral';
  };

  const sourceIcons: Record<string, string> = {
    trustpilot: '⭐',
    google: '🔍',
    feefo: '✓',
    csv_import: '📄',
  };

  return (
    <div className="container mx-auto px-6 py-12">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-neutral-100 mb-8">Settings</h1>

        {/* Connectors Section */}
        <div className="card mb-8">
          <h2 className="section-title">Review Source Connectors</h2>

          {loading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="loading-skeleton h-20 rounded" />
              ))}
            </div>
          ) : (
            <div className="space-y-4">
              {sources.map((source) => (
                <div
                  key={source.source}
                  className="flex items-center justify-between p-4 bg-neutral-800/50 rounded-lg"
                >
                  <div className="flex items-center gap-4">
                    <div className="text-2xl">{sourceIcons[source.source] || '📊'}</div>
                    <div>
                      <div className="text-sm font-medium text-neutral-200 mb-1">
                        {source.name}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`badge ${getStatusBadge(source.status)} text-xs`}>
                          {source.status}
                        </span>
                        {source.enabled && (
                          <span className="text-xs text-neutral-500">Enabled</span>
                        )}
                      </div>
                    </div>
                  </div>
                  
                  {source.source !== 'csv_import' && (
                    <button className="btn btn-secondary text-sm">
                      {source.enabled ? 'Configure' : 'Enable'}
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}

          <div className="mt-6 p-4 bg-amber-600/10 border border-amber-600/30 rounded-lg">
            <div className="flex items-start gap-3">
              <div className="text-xl">💡</div>
              <div className="text-sm text-neutral-300">
                <strong className="text-amber-500">Demo Mode:</strong> This MVP uses demo connectors.
                To enable real API integrations, add your API keys in environment variables and
                restart the application.
              </div>
            </div>
          </div>
        </div>

        {/* CSV Upload Section */}
        <div className="card mb-8">
          <h2 className="section-title">Import Reviews from CSV</h2>
          
          <form onSubmit={handleCSVUpload} className="space-y-6">
            {/* Business selection (simplified for demo) */}
            <div>
              <label className="block text-sm font-medium text-neutral-300 mb-2">
                Business ID
              </label>
              <input
                type="text"
                name="businessId"
                placeholder="Enter business ID"
                required
                className="input"
              />
              <p className="text-xs text-neutral-500 mt-1">
                Get this from the business detail page URL
              </p>
            </div>

            {/* File upload */}
            <div>
              <label className="block text-sm font-medium text-neutral-300 mb-2">
                CSV File
              </label>
              <input
                type="file"
                name="file"
                accept=".csv"
                required
                className="input file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-amber-600 file:text-neutral-950 hover:file:bg-amber-500"
              />
              <p className="text-xs text-neutral-500 mt-1">
                CSV should include: author, text, rating, date columns
              </p>
            </div>

            {/* Column mapping (simplified) */}
            <div>
              <label className="block text-sm font-medium text-neutral-300 mb-2">
                Column Mapping (JSON)
              </label>
              <textarea
                name="mapping"
                rows={4}
                defaultValue={JSON.stringify({
                  authorName: 'author',
                  text: 'review',
                  rating: 'stars',
                  date: 'date'
                }, null, 2)}
                required
                className="input font-mono text-xs"
              />
              <p className="text-xs text-neutral-500 mt-1">
                Map CSV columns to review fields
              </p>
            </div>

            {/* Status message */}
            {uploadStatus && (
              <div
                className={`p-4 rounded-lg ${
                  uploadStatus.type === 'success'
                    ? 'bg-emerald-600/20 border border-emerald-600/30 text-emerald-400'
                    : 'bg-red-600/20 border border-red-600/30 text-red-400'
                }`}
              >
                {uploadStatus.message}
              </div>
            )}

            {/* Submit button */}
            <button
              type="submit"
              disabled={uploading}
              className="btn btn-primary w-full"
            >
              {uploading ? (
                <span className="flex items-center justify-center gap-2">
                  <svg className="animate-spin h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Uploading...
                </span>
              ) : (
                'Upload CSV'
              )}
            </button>
          </form>
        </div>

        {/* Scoring Configuration */}
        <div className="card">
          <h2 className="section-title">Scoring Configuration</h2>
          
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-neutral-300 mb-2">
                Recency Half-Life (days)
              </label>
              <input
                type="number"
                defaultValue={90}
                min={1}
                max={365}
                className="input w-32"
              />
              <p className="text-xs text-neutral-500 mt-1">
                Reviews lose 50% weight after this many days
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-neutral-300 mb-2">
                Minimum Reviews for Confidence
              </label>
              <input
                type="number"
                defaultValue={20}
                min={5}
                max={100}
                className="input w-32"
              />
              <p className="text-xs text-neutral-500 mt-1">
                Threshold for high confidence scores
              </p>
            </div>

            <div>
              <h3 className="text-sm font-medium text-neutral-300 mb-3">Source Weights</h3>
              <div className="space-y-2">
                {sources.map((source) => (
                  <div key={source.source} className="flex items-center justify-between">
                    <span className="text-sm text-neutral-400">{source.name}</span>
                    <input
                      type="number"
                      step="0.1"
                      min="0"
                      max="2"
                      defaultValue={source.source === 'csv_import' ? 0.8 : 1.0}
                      className="input w-24 text-sm"
                    />
                  </div>
                ))}
              </div>
            </div>

            <button className="btn btn-secondary mt-4">
              Save Configuration
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
