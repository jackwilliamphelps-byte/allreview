import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { getAllConnectors } from '@/lib/connectors';

const prisma = new PrismaClient();

export async function GET(request: NextRequest) {
  try {
    const connectors = getAllConnectors();
    const configs = await prisma.connectorConfig.findMany();

    const sources = connectors.map(connector => {
      const config = configs.find(c => c.source === connector.source);
      return {
        source: connector.source,
        name: connector.name,
        enabled: config?.enabled || false,
        status: config?.status || 'unconfigured',
      };
    });

    return NextResponse.json({ sources });
  } catch (error) {
    console.error('Get sources error:', error);
    return NextResponse.json({ error: 'Failed to fetch sources' }, { status: 500 });
  }
}
