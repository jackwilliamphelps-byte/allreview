import { NextRequest, NextResponse } from 'next/server';
import { ScoringService } from '@/lib/services/scoring';

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const scoringService = new ScoringService();
    const result = await scoringService.calculateBusinessScore(params.id);
    return NextResponse.json(result);
  } catch (error) {
    console.error('Score calculation error:', error);
    return NextResponse.json({ error: 'Failed to calculate score' }, { status: 500 });
  }
}
