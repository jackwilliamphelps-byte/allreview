// Connector interface for extensible source integration
// Each source implements this interface for consistent ingestion

export interface SearchQuery {
  businessName?: string;
  website?: string;
  location?: {
    city?: string;
    postcode?: string;
    country?: string;
  };
}

export interface ProfileMatch {
  externalId: string;
  externalUrl?: string;
  displayName: string;
  claimedStatus?: 'claimed' | 'unclaimed' | 'unknown';
  matchConfidence: number; // 0-1
  metadata?: Record<string, any>;
}

export interface ReviewData {
  externalId: string;
  authorName?: string;
  authorId?: string;
  title?: string;
  text?: string;
  ratingOriginal: string;
  ratingNormalised: number; // 0-100
  ratingType: 'stars_5' | 'stars_10' | 'percentage' | 'thumbs';
  reviewDate: Date;
  verifiedPurchase?: boolean;
  metadata?: Record<string, any>;
}

export interface ProfileSummary {
  totalReviews: number;
  averageRating: number; // In source's original scale
  ratingDistribution?: Record<string, number>;
  lastReviewDate?: Date;
}

export interface PaginationParams {
  page?: number;
  limit?: number;
  cursor?: string;
}

export interface PaginatedResult<T> {
  data: T[];
  pagination: {
    hasMore: boolean;
    nextCursor?: string;
    total?: number;
  };
}

// Core connector interface
export interface SourceConnector {
  readonly name: string;
  readonly source: string; // Unique identifier (e.g., 'trustpilot', 'google')
  
  // Search for profiles matching a business
  searchProfiles(query: SearchQuery): Promise<ProfileMatch[]>;
  
  // Fetch reviews for a specific profile
  fetchReviews(
    profileRef: { externalId: string },
    pagination?: PaginationParams
  ): Promise<PaginatedResult<ReviewData>>;
  
  // Fetch summary statistics (optional, can return empty)
  fetchSummary(profileRef: { externalId: string }): Promise<ProfileSummary | null>;
  
  // Test connection (for configuration UI)
  testConnection?(): Promise<{ success: boolean; message: string }>;
}

// Helper: Normalise ratings to 0-100 scale
export function normaliseRating(
  original: string | number,
  type: 'stars_5' | 'stars_10' | 'percentage' | 'thumbs'
): number {
  const value = typeof original === 'string' ? parseFloat(original) : original;
  
  switch (type) {
    case 'stars_5':
      return (value / 5) * 100;
    case 'stars_10':
      return (value / 10) * 100;
    case 'percentage':
      return value;
    case 'thumbs':
      // thumbs_up = 100, thumbs_down = 0
      return original === 'thumbs_up' || value === 1 ? 100 : 0;
    default:
      return value;
  }
}

// Helper: Detect rating type from original value
export function detectRatingType(original: string): 'stars_5' | 'stars_10' | 'percentage' | 'thumbs' {
  if (original === 'thumbs_up' || original === 'thumbs_down') return 'thumbs';
  
  const value = parseFloat(original);
  if (isNaN(value)) return 'stars_5'; // Default fallback
  
  if (value <= 5) return 'stars_5';
  if (value <= 10) return 'stars_10';
  return 'percentage';
}
