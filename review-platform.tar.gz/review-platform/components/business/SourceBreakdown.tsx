'use client';

import { useState } from 'react';

interface Source {
  source: string;
  profileId: string;
  displayName: string;
  score: number;
  reviewCount: number;
  averageRating: number;
  weight: number;
}

interface SourceBreakdownProps {
  sources: Source[];
}

const sourceConfig: Record<string, { icon: string; color: string; name: string }> = {
  trustpilot: { icon: '⭐', color: 'text-green-500', name: 'Trustpilot' },
  google: { icon: '🔍', color: 'text-blue-500', name: 'Google' },
  feefo: { icon: '✓', color: 'text-purple-500', name: 'Feefo' },
  csv_import: { icon: '📄', color: 'text-neutral-400', name: 'CSV Import' },
};

export default function SourceBreakdown({ sources }: SourceBreakdownProps) {
  const [expandedSource, setExpandedSource] = useState<string | null>(null);

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-emerald-500';
    if (score >= 60) return 'text-amber-500';
    return 'text-orange-500';
  };

  const totalReviews = sources.reduce((sum, s) => sum + s.reviewCount, 0);

  return (
    <div className="card">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-neutral-300">Source Breakdown</h3>
        <span className="text-xs text-neutral-500">{sources.length} sources</span>
      </div>

      <div className="space-y-4">
        {sources.map((source) => {
          const config = sourceConfig[source.source] || { 
            icon: '📊', 
            color: 'text-neutral-400', 
            name: source.source 
          };
          const percentage = (source.reviewCount / totalReviews) * 100;
          const isExpanded = expandedSource === source.source;

          return (
            <div 
              key={source.profileId}
              className="group"
            >
              <div 
                className="flex items-center gap-4 cursor-pointer hover:bg-neutral-800/50 p-3 -mx-3 rounded-lg transition-colors"
                onClick={() => setExpandedSource(isExpanded ? null : source.source)}
              >
                {/* Icon */}
                <div className={`text-2xl ${config.color} transition-transform group-hover:scale-110`}>
                  {config.icon}
                </div>
                
                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-sm font-medium text-neutral-200">
                        {source.displayName}
                      </span>
                      {source.weight !== 1.0 && (
                        <span className="text-xs text-neutral-500">
                          (weight: {source.weight.toFixed(1)})
                        </span>
                      )}
                    </div>
                    <span className={`text-lg font-bold ${getScoreColor(source.score)}`}>
                      {source.score.toFixed(1)}
                    </span>
                  </div>
                  
                  {/* Progress bar */}
                  <div className="flex items-center gap-3">
                    <div className="flex-1 bg-neutral-800 rounded-full h-2 overflow-hidden">
                      <div
                        className={`h-2 rounded-full transition-all duration-500 ${
                          source.score >= 80 ? 'bg-emerald-600' :
                          source.score >= 60 ? 'bg-amber-600' : 'bg-orange-600'
                        }`}
                        style={{ width: `${source.score}%` }}
                      />
                    </div>
                    <span className="text-xs text-neutral-500 whitespace-nowrap">
                      {source.reviewCount} reviews
                    </span>
                  </div>

                  {/* Expanded details */}
                  {isExpanded && (
                    <div className="mt-3 pt-3 border-t border-neutral-800 grid grid-cols-3 gap-3 text-xs">
                      <div>
                        <div className="text-neutral-500 mb-1">Avg Rating</div>
                        <div className="text-neutral-200 font-semibold">
                          {source.averageRating.toFixed(1)} / 5
                        </div>
                      </div>
                      <div>
                        <div className="text-neutral-500 mb-1">Share</div>
                        <div className="text-neutral-200 font-semibold">
                          {percentage.toFixed(1)}%
                        </div>
                      </div>
                      <div>
                        <div className="text-neutral-500 mb-1">Weight</div>
                        <div className="text-neutral-200 font-semibold">
                          {source.weight.toFixed(1)}x
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* Expand indicator */}
                <div className={`text-neutral-500 transition-transform ${isExpanded ? 'rotate-180' : ''}`}>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Summary */}
      <div className="mt-6 pt-4 border-t border-neutral-800">
        <div className="flex items-center justify-between text-sm">
          <span className="text-neutral-400">Weighted Average</span>
          <span className="text-neutral-200 font-semibold">
            {(sources.reduce((sum, s) => sum + s.score * s.weight * s.reviewCount, 0) /
              sources.reduce((sum, s) => sum + s.weight * s.reviewCount, 0)).toFixed(1)}
          </span>
        </div>
      </div>
    </div>
  );
}
