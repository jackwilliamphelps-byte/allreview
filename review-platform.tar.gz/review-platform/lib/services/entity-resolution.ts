// Entity resolution service: Match and merge business entities

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

export interface BusinessMatch {
  businessId: string;
  name: string;
  website?: string | null;
  city?: string | null;
  postcode?: string | null;
  confidence: number; // 0-1
  matchReason: string;
}

export interface ResolveResult {
  exactMatch?: BusinessMatch;
  possibleMatches: BusinessMatch[];
  shouldCreate: boolean;
}

export class EntityResolutionService {
  /**
   * Resolve a business query to existing entities or suggest creation
   */
  async resolve(query: {
    name: string;
    website?: string;
    postcode?: string;
    city?: string;
  }): Promise<ResolveResult> {
    const possibleMatches: BusinessMatch[] = [];

    // 1. Exact website match (highest confidence)
    if (query.website) {
      const normalizedWebsite = this.normalizeWebsite(query.website);
      const websiteMatch = await prisma.business.findFirst({
        where: {
          website: {
            contains: normalizedWebsite,
            mode: 'insensitive',
          },
        },
      });

      if (websiteMatch) {
        return {
          exactMatch: {
            businessId: websiteMatch.id,
            name: websiteMatch.name,
            website: websiteMatch.website,
            city: websiteMatch.city,
            postcode: websiteMatch.postcode,
            confidence: 1.0,
            matchReason: 'Exact website match',
          },
          possibleMatches: [],
          shouldCreate: false,
        };
      }
    }

    // 2. Fuzzy name matching with location
    const nameMatches = await prisma.business.findMany({
      where: {
        OR: [
          { name: { contains: query.name, mode: 'insensitive' } },
          { name: { startsWith: query.name, mode: 'insensitive' } },
        ],
      },
      take: 10,
    });

    for (const business of nameMatches) {
      let confidence = this.calculateNameSimilarity(query.name, business.name);

      // Boost confidence if location matches
      if (query.postcode && business.postcode) {
        if (this.normalizePostcode(query.postcode) === this.normalizePostcode(business.postcode)) {
          confidence = Math.min(1.0, confidence + 0.3);
        }
      } else if (query.city && business.city) {
        if (query.city.toLowerCase() === business.city.toLowerCase()) {
          confidence = Math.min(1.0, confidence + 0.2);
        }
      }

      if (confidence > 0.5) {
        possibleMatches.push({
          businessId: business.id,
          name: business.name,
          website: business.website,
          city: business.city,
          postcode: business.postcode,
          confidence,
          matchReason: this.getMatchReason(confidence, query, business),
        });
      }
    }

    // Sort by confidence
    possibleMatches.sort((a, b) => b.confidence - a.confidence);

    // Exact match if confidence >= 0.95
    const exactMatch = possibleMatches[0]?.confidence >= 0.95 
      ? possibleMatches[0] 
      : undefined;

    return {
      exactMatch,
      possibleMatches: exactMatch ? [] : possibleMatches.slice(0, 5),
      shouldCreate: possibleMatches.length === 0 || possibleMatches[0].confidence < 0.7,
    };
  }

  /**
   * Create a new business entity
   */
  async createBusiness(data: {
    name: string;
    website?: string;
    description?: string;
    addressLine1?: string;
    addressLine2?: string;
    city?: string;
    postcode?: string;
    country?: string;
  }) {
    return await prisma.business.create({
      data: {
        ...data,
        country: data.country || 'GB',
      },
    });
  }

  /**
   * Merge two businesses
   */
  async mergeBusinesses(keepId: string, mergeId: string): Promise<void> {
    await prisma.$transaction(async (tx) => {
      // Move profiles
      await tx.profile.updateMany({
        where: { businessId: mergeId },
        data: { businessId: keepId },
      });

      // Move signals
      await tx.signal.updateMany({
        where: { businessId: mergeId },
        data: { businessId: keepId },
      });

      // Move score snapshots
      await tx.scoreSnapshot.updateMany({
        where: { businessId: mergeId },
        data: { businessId: keepId },
      });

      // Delete merged business
      await tx.business.delete({
        where: { id: mergeId },
      });
    });
  }

  // Helper: Calculate Levenshtein-based name similarity
  private calculateNameSimilarity(name1: string, name2: string): number {
    const n1 = this.normalizeName(name1);
    const n2 = this.normalizeName(name2);

    if (n1 === n2) return 1.0;

    const distance = this.levenshteinDistance(n1, n2);
    const maxLength = Math.max(n1.length, n2.length);
    
    return 1 - (distance / maxLength);
  }

  // Helper: Levenshtein distance
  private levenshteinDistance(str1: string, str2: string): number {
    const matrix: number[][] = [];

    for (let i = 0; i <= str2.length; i++) {
      matrix[i] = [i];
    }

    for (let j = 0; j <= str1.length; j++) {
      matrix[0][j] = j;
    }

    for (let i = 1; i <= str2.length; i++) {
      for (let j = 1; j <= str1.length; j++) {
        if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
          matrix[i][j] = matrix[i - 1][j - 1];
        } else {
          matrix[i][j] = Math.min(
            matrix[i - 1][j - 1] + 1,
            matrix[i][j - 1] + 1,
            matrix[i - 1][j] + 1
          );
        }
      }
    }

    return matrix[str2.length][str1.length];
  }

  // Helper: Normalize name for comparison
  private normalizeName(name: string): string {
    return name
      .toLowerCase()
      .replace(/[^\w\s]/g, '')
      .replace(/\s+/g, ' ')
      .trim();
  }

  // Helper: Normalize website
  private normalizeWebsite(website: string): string {
    return website
      .replace(/^https?:\/\//i, '')
      .replace(/^www\./i, '')
      .replace(/\/$/, '')
      .toLowerCase();
  }

  // Helper: Normalize postcode
  private normalizePostcode(postcode: string): string {
    return postcode.replace(/\s/g, '').toUpperCase();
  }

  // Helper: Generate match reason
  private getMatchReason(
    confidence: number,
    query: any,
    business: any
  ): string {
    if (confidence >= 0.9) {
      return 'Strong name and location match';
    } else if (confidence >= 0.7 && query.postcode && business.postcode) {
      return 'Name match with same postcode';
    } else if (confidence >= 0.7) {
      return 'Strong name similarity';
    } else {
      return 'Partial name match';
    }
  }
}
